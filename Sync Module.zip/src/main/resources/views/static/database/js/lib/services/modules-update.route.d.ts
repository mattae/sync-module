import { Routes } from '@angular/router';
export declare const ROUTES: Routes;
