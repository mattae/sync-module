import { ModuleUpdate } from '../model/module.model';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot, Routes } from '@angular/router';
import { ModuleManagementService } from './module.management.service';
import { Observable } from 'rxjs';
export declare class ModuleResolve implements Resolve<ModuleUpdate> {
    private service;
    constructor(service: ModuleManagementService);
    resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<ModuleUpdate>;
}
export declare const ROUTES: Routes;
