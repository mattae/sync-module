export declare class UpdatesModule {
}
