import { OnDestroy, OnInit } from '@angular/core';
import { ModuleUpdate } from '../../model/module.model';
import { ModuleManagementService } from '../../services/module.management.service';
import { CardViewItem } from '@alfresco/adf-core';
import { ActivatedRoute, Router } from '@angular/router';
export declare class ModuleListComponent implements OnInit, OnDestroy {
    private moduleManagementService;
    private router;
    private route;
    modules: ModuleUpdate[];
    constructor(moduleManagementService: ModuleManagementService, router: Router, route: ActivatedRoute);
    ngOnInit(): void;
    ngOnDestroy(): void;
    getProperties(module: ModuleUpdate): Array<CardViewItem>;
    update(module: ModuleUpdate): void;
    uninstall(module: ModuleUpdate): void;
    previousState(): void;
}
