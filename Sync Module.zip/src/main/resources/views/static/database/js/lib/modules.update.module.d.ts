export declare class ModulesUpdateModule {
}
