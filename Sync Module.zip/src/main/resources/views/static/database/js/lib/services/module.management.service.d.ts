import { HttpClient } from '@angular/common/http';
import { ServerApiUrlConfig } from '@lamis/web-core';
import { ModuleUpdate } from '../model/module.model';
export declare class ModuleManagementService {
    protected http: HttpClient;
    private serverUrl;
    resourceUrl: string;
    constructor(http: HttpClient, serverUrl: ServerApiUrlConfig);
    findById(id: number): import("rxjs").Observable<import("@angular/common/http").HttpResponse<ModuleUpdate>>;
    availableModules(): import("rxjs").Observable<ModuleUpdate[]>;
    uploadModule(form: any): import("rxjs").Observable<import("@angular/common/http").HttpResponse<ModuleUpdate>>;
    install(module: any): import("rxjs").Observable<import("@angular/common/http").HttpResponse<ModuleUpdate>>;
    uninstall(module: any): import("rxjs").Observable<import("@angular/common/http").HttpResponse<ModuleUpdate>>;
}
