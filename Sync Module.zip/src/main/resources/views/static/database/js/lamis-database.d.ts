/**
 * Generated bundle index. Do not edit.
 */
export * from './public_api';
export { DatabaseSyncComponent as ɵh } from './lib/components/database-sync/database.sync.component';
export { ModulesUpdateComponent as ɵa } from './lib/components/modules-update/modules-update.component';
export { ModuleListComponent as ɵk } from './lib/components/updates-management/module.list.component';
export { ModuleUpdateComponent as ɵm } from './lib/components/updates-management/module.update.component';
export { UploadReportComponent as ɵn } from './lib/components/upload-report/upload.report.component';
export { MaterialModule as ɵf, modules as ɵe } from './lib/material.module';
export { ROUTES as ɵg } from './lib/services/database.sync.route';
export { ModuleManagementService as ɵl } from './lib/services/module.management.service';
export { ROUTES as ɵd } from './lib/services/modules-update.route';
export { ModuleResolve as ɵi, ROUTES as ɵj } from './lib/services/modules.update.route';
export { ModulesUpdateService as ɵb } from './lib/services/modules.update.service';
export { SyncService as ɵc } from './lib/services/sync.service';
