import { Routes } from '@angular/router';
export declare const ROUTES: Routes;
export declare class UploadReportModule {
}
