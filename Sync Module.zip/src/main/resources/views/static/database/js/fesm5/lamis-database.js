import { __decorate, __param, __spread } from 'tslib';
import { CardViewDatetimeItemModel, CardViewTextItemModel, CoreModule, CardViewBoolItemModel, NotificationService } from '@alfresco/adf-core';
import { CommonModule } from '@angular/common';
import { Inject, ɵɵdefineInjectable, ɵɵinject, Injectable, Component, NgModule } from '@angular/core';
import { MatInputModule, MatIconModule, MatCardModule, MatSelectModule, MatButtonModule, MatProgressBarModule, MatTableModule, MatListModule, MatAutocompleteModule, MatCheckboxModule, MatChipsModule, MatDatepickerModule, MatDialogModule, MatGridListModule, MatNativeDateModule, MatOptionModule, MatProgressSpinnerModule, MatRadioModule, MatRippleModule, MatSlideToggleModule, MatTabsModule, MatMenuModule, MatSidenavModule, MatSnackBarModule, MatToolbarModule, MatTooltipModule } from '@angular/material';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { CovalentMessageModule, CovalentDialogsModule, CovalentCommonModule, CovalentFileModule } from '@covalent/core';
import { HttpClient } from '@angular/common/http';
import { SERVER_API_URL_CONFIG, MatDateFormatModule, AppLoaderService, UserRouteAccessService, LamisSharedModule } from '@lamis/web-core';
import { map, catchError, filter } from 'rxjs/operators';
import * as moment_ from 'moment';
import { RxStompService } from '@stomp/ng2-stompjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomFormsModule } from 'ng2-validation';
import { MatDatetimepickerModule, MatNativeDatetimeModule } from '@mat-datetimepicker/core';
import { of } from 'rxjs';
import { saveAs } from 'file-saver';

var moment = moment_;
var ModulesUpdateService = /** @class */ (function () {
    function ModulesUpdateService(http, serverUrl) {
        this.http = http;
        this.serverUrl = serverUrl;
        this.resourceUrl = '';
        this.resourceUrl = serverUrl.SERVER_API_URL + '/api/modules-update';
    }
    ModulesUpdateService.prototype.installUpdates = function () {
        return this.http.get(this.resourceUrl + "/install-updates");
    };
    ModulesUpdateService.prototype.availableUpdates = function () {
        return this.http.get(this.resourceUrl + "/available-modules");
    };
    ModulesUpdateService.prototype.checkForUpdates = function () {
        return this.http.get(this.resourceUrl + "/check-for-updates");
    };
    ModulesUpdateService.prototype.lastHeartbeat = function () {
        return this.http.get(this.resourceUrl + "/last-heartbeat").pipe(map(function (res) {
            res = res != null ? moment(res, moment.ISO_8601) : null;
            return res;
        }));
    };
    ModulesUpdateService.ctorParameters = function () { return [
        { type: HttpClient },
        { type: undefined, decorators: [{ type: Inject, args: [SERVER_API_URL_CONFIG,] }] }
    ]; };
    ModulesUpdateService.ngInjectableDef = ɵɵdefineInjectable({ factory: function ModulesUpdateService_Factory() { return new ModulesUpdateService(ɵɵinject(HttpClient), ɵɵinject(SERVER_API_URL_CONFIG)); }, token: ModulesUpdateService, providedIn: "root" });
    ModulesUpdateService = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __param(1, Inject(SERVER_API_URL_CONFIG))
    ], ModulesUpdateService);
    return ModulesUpdateService;
}());

var SyncService = /** @class */ (function () {
    function SyncService(http, serverUrl) {
        this.http = http;
        this.serverUrl = serverUrl;
        this.resourceUrl = '';
        this.resourceUrl = serverUrl.SERVER_API_URL + '/api/database-sync';
    }
    SyncService.prototype.sync = function () {
        return this.http.get(this.resourceUrl + "/sync");
    };
    SyncService.prototype.downloadBiometrics = function () {
        return this.http.get(this.resourceUrl + "/download-biometrics");
    };
    SyncService.prototype.uploadBiometrics = function () {
        return this.http.get(this.resourceUrl + "/upload-biometrics");
    };
    SyncService.prototype.biometricDownloadCompleted = function () {
        return this.http.get(this.resourceUrl + "/biometric-download-completed");
    };
    SyncService.prototype.biometricUploadCompleted = function () {
        return this.http.get(this.resourceUrl + "/biometric-upload-completed");
    };
    SyncService.prototype.downloadCparp = function (facilityId) {
        return this.http.get(this.resourceUrl + "/cparp/update/" + facilityId);
    };
    SyncService.prototype.downloadMobileRecords = function () {
        return this.http.get(this.resourceUrl + "/download-records");
    };
    SyncService.prototype.init = function () {
        return this.http.get(this.resourceUrl + "/init");
    };
    SyncService.prototype.states = function () {
        return this.http.get(this.resourceUrl + "/states");
    };
    SyncService.prototype.getActiveFacility = function () {
        return this.http.get('/api/facilities/active');
    };
    SyncService.prototype.destroy = function () {
        return this.http.get(this.resourceUrl + "/destroy");
    };
    SyncService.prototype.uploadReport = function (stateId, format) {
        return this.http.get(this.resourceUrl + "/upload-report?stateId=" + stateId + "&format=" + format, { responseType: 'blob' });
    };
    SyncService.ctorParameters = function () { return [
        { type: HttpClient },
        { type: undefined, decorators: [{ type: Inject, args: [SERVER_API_URL_CONFIG,] }] }
    ]; };
    SyncService.ngInjectableDef = ɵɵdefineInjectable({ factory: function SyncService_Factory() { return new SyncService(ɵɵinject(HttpClient), ɵɵinject(SERVER_API_URL_CONFIG)); }, token: SyncService, providedIn: "root" });
    SyncService = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __param(1, Inject(SERVER_API_URL_CONFIG))
    ], SyncService);
    return SyncService;
}());

var moment$1 = moment_;
var ModulesUpdateComponent = /** @class */ (function () {
    function ModulesUpdateComponent(service, stompService, syncService) {
        this.service = service;
        this.stompService = stompService;
        this.syncService = syncService;
        this.modules = [];
        this.isUpdating = false;
        this.installed = false;
        this.completeChecking = false;
        this.checked = false;
        this.properties = [];
        this.serverContacted = false;
    }
    ModulesUpdateComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.statusSubscription = this.stompService.watch('/topic/update/download/completed').subscribe(function (msg) {
            _this.completeChecking = msg.body === 'true';
            _this.checked = true;
            _this.service.availableUpdates().subscribe(function (res) { return _this.modules = res; });
        });
        this.service.availableUpdates().subscribe(function (res) { return _this.modules = res; });
        this.service.lastHeartbeat().subscribe(function (res) {
            _this.serverContacted = !!res;
            _this.properties = [];
            _this.properties.push(new CardViewDatetimeItemModel({
                key: 'hb',
                label: 'Last Contact with Server',
                value: res,
                format: 'DD MMM, YYYY HH:MM'
            }));
        });
    };
    ModulesUpdateComponent.prototype.ngOnDestroy = function () {
        this.statusSubscription.unsubscribe();
    };
    ModulesUpdateComponent.prototype.checkForUpdates = function () {
        var _this = this;
        this.service.checkForUpdates().subscribe(function (res) {
            _this.checked = true;
            _this.completeChecking = false;
        });
    };
    ModulesUpdateComponent.prototype.getProperties = function (module) {
        var properties = [];
        var description = new CardViewTextItemModel({
            label: 'Name',
            value: module.name,
            key: 'desc',
        });
        properties.push(description);
        var version = new CardViewTextItemModel({
            label: 'version',
            value: module.version,
            key: 'version',
        });
        properties.push(version);
        var active = new CardViewDatetimeItemModel({
            label: 'Build Time',
            value: moment$1(module.buildTime),
            key: 'active',
            format: 'DD MMM, YYYY HH:MM'
        });
        properties.push(active);
        return properties;
    };
    ModulesUpdateComponent.prototype.updateModules = function () {
        var _this = this;
        this.isUpdating = true;
        this.installed = false;
        this.service.installUpdates().subscribe(function (res) {
            _this.modules = res;
            _this.isUpdating = false;
            _this.installed = true;
            _this.service.availableUpdates().subscribe(function (res) { return _this.modules = res; });
        });
    };
    ModulesUpdateComponent.prototype.previousState = function () {
        window.history.back();
    };
    ModulesUpdateComponent.ctorParameters = function () { return [
        { type: ModulesUpdateService },
        { type: RxStompService },
        { type: SyncService }
    ]; };
    ModulesUpdateComponent = __decorate([
        Component({
            selector: 'modules-update',
            template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <mat-card-header *ngIf=\"installed\">\n                <mat-card-title>\n                    <p style=\"color: green\">\n                        Updates installed; please restart service or system\n                    </p>\n                </mat-card-title>\n            </mat-card-header>\n            <ng-container *ngIf=\"!completeChecking && checked\">\n                <div class=\"full-width\">\n                    <mat-progress-bar class=\"full-width\" mode=\"indeterminate\"></mat-progress-bar>\n                </div>\n            </ng-container>\n            <mat-card-content>\n                <adf-card-view [properties]=\"properties\" editable=\"false\"></adf-card-view>\n                <mat-divider [inset]=\"true\"></mat-divider>\n                <div class=\"row\" *ngIf=\"modules\">\n                    <div class=\"col-sm-12 col-md-6 col-lg-4\"\n                         *ngFor=\"let module of modules\">\n                        <mat-card class=\"\">\n                            <mat-card-content>\n                                <adf-card-view [properties]=\"getProperties(module)\"></adf-card-view>\n                            </mat-card-content>\n                        </mat-card>\n                    </div>\n                </div>\n                <adf-empty-content\n                        *ngIf=\"!modules.length && checked && completeChecking\"\n                        icon=\"group\"\n                        [title]=\"'No updates available'\">\n                </adf-empty-content>\n                <mat-divider></mat-divider>\n                <mat-card-actions style=\"text-align: right !important;\">\n                    <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n                    <button mat-raised-button color='accent'\n                            (click)=\"checkForUpdates()\"\n                            [disabled]=\"!completeChecking && checked || isUpdating || !serverContacted\"\n                            type=\"button\">\n                        Check for Updates\n                    </button>\n                    <button mat-raised-button color='primary' *ngIf=\"!!modules.length\"\n                            (click)=\"updateModules()\"\n                            [disabled]=\"!completeChecking && checked || isUpdating\"\n                            type=\"button\">\n                        Install Updates\n                    </button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
        })
    ], ModulesUpdateComponent);
    return ModulesUpdateComponent;
}());

var ɵ0 = {
    title: 'Module Updates',
    breadcrumb: 'MODULE UPDATES'
}, ɵ1 = {
    authorities: ['ROLE_ADMIN'],
    title: 'Module Updates',
    breadcrumb: 'MODULE UPDATES'
};
var ROUTES = [
    {
        path: '',
        data: ɵ0,
        children: [
            {
                path: '',
                component: ModulesUpdateComponent,
                data: ɵ1,
            }
        ]
    }
];

var UpdatesModule = /** @class */ (function () {
    function UpdatesModule() {
    }
    UpdatesModule = __decorate([
        NgModule({
            declarations: [
                ModulesUpdateComponent
            ],
            imports: [
                CommonModule,
                MatInputModule,
                MatIconModule,
                MatCardModule,
                MatSelectModule,
                MatButtonModule,
                RouterModule.forChild(ROUTES),
                MatProgressBarModule,
                FormsModule,
                CovalentMessageModule,
                CovalentDialogsModule,
                MatTableModule,
                MatListModule,
                CoreModule,
                ReactiveFormsModule,
                MatDateFormatModule,
                CustomFormsModule
            ],
            exports: [],
            entryComponents: [],
            providers: []
        })
    ], UpdatesModule);
    return UpdatesModule;
}());

/*!
 * @license
 * Copyright 2016 Alfresco Software, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function modules() {
    return [
        MatAutocompleteModule, MatButtonModule, MatCardModule, MatCheckboxModule,
        MatChipsModule, MatDatepickerModule, MatDialogModule, MatGridListModule, MatIconModule,
        MatInputModule, MatListModule, MatNativeDateModule, MatOptionModule, MatProgressSpinnerModule, MatRadioModule,
        MatRippleModule, MatSelectModule, MatSlideToggleModule, MatTableModule, MatTabsModule,
        MatMenuModule, MatProgressBarModule, MatSidenavModule, MatSnackBarModule, MatToolbarModule,
        MatTooltipModule, MatDatetimepickerModule, MatNativeDatetimeModule
    ];
}
var MaterialModule = /** @class */ (function () {
    function MaterialModule() {
    }
    MaterialModule = __decorate([
        NgModule({
            imports: modules(),
            exports: modules()
        })
    ], MaterialModule);
    return MaterialModule;
}());

var moment$2 = moment_;
var DatabaseSyncComponent = /** @class */ (function () {
    function DatabaseSyncComponent(stompService, syncService, notification, loaderService) {
        this.stompService = stompService;
        this.syncService = syncService;
        this.notification = notification;
        this.loaderService = loaderService;
        this.syncing = false;
        this.downloading = false;
        this.serverContacted = false;
        this.tables = '';
        this.properties = [];
    }
    DatabaseSyncComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.syncService.getActiveFacility().subscribe(function (res) { return _this.facility = res; });
        this.properties = [];
        this.statusSubscription = this.stompService.watch('/topic/sync/server-status').subscribe(function (msg) {
            _this.properties = _this.properties.filter(function (i) { return i.key !== 'server'; });
            _this.insertAt(_this.properties, 0, (new CardViewDatetimeItemModel({
                key: 'server',
                value: msg.body && moment$2(msg.body, moment$2.ISO_8601) || null,
                label: 'Last contact with Server',
                format: 'DD MMM, YYYY HH:MM'
            })));
        });
        this.statusSubscription = this.stompService.watch('/topic/sync/sync-status').subscribe(function (msg) {
            _this.properties = _this.properties.filter(function (i) { return i.key !== 'sync'; });
            _this.insertAt(_this.properties, 1, (new CardViewDatetimeItemModel({
                key: 'sync',
                value: msg.body && moment$2(msg.body, moment$2.ISO_8601) || null,
                label: 'Last Sync to Server',
                format: 'DD MMM, YYYY HH:MM'
            })));
        });
        this.syncSubscription = this.stompService.watch('/topic/sync/upload-status/completed').subscribe(function (msg) {
            _this.syncing = msg.body === 'false';
            _this.properties = _this.properties.filter(function (i) { return i.key !== 'status'; });
            _this.properties.push(new CardViewBoolItemModel({
                key: 'status',
                value: msg.body === 'true',
                label: 'Upload Completed',
            }));
        });
        this.tableSubscription = this.stompService.watch('/topic/sync/table-status').subscribe(function (msg) {
            _this.tables = msg.body;
        });
        this.serverSubscription = this.stompService.watch('/topic/sync/server').subscribe(function (msg) {
            _this.serverContacted = !!msg.body;
        });
        this.syncService.init().subscribe();
    };
    DatabaseSyncComponent.prototype.ngOnDestroy = function () {
        this.statusSubscription.unsubscribe();
        this.tableSubscription.unsubscribe();
        this.syncSubscription.unsubscribe();
        this.syncService.destroy().subscribe();
        this.serverSubscription.unsubscribe();
    };
    DatabaseSyncComponent.prototype.sync = function () {
        this.syncing = true;
        this.syncService.sync().subscribe();
    };
    DatabaseSyncComponent.prototype.downloadCparp = function () {
        var _this = this;
        this.downloading = true;
        this.loaderService.open('Downloading records, please wait...');
        this.syncService.downloadCparp(this.facility.id).pipe(map(function (res) {
            _this.loaderService.close();
            _this.downloading = false;
            _this.notification.showInfo("Available records for facility successfully downloaded");
        }), catchError(function (err) {
            _this.loaderService.close();
            _this.notification.showError("There was an error downloading records; please try again");
            _this.downloading = false;
            return of();
        })).subscribe();
    };
    DatabaseSyncComponent.prototype.downloadMobileRecords = function () {
        var _this = this;
        this.downloading = true;
        this.loaderService.open('Downloading records, please wait...');
        this.syncService.downloadMobileRecords().pipe(map(function (res) {
            _this.loaderService.close();
            _this.downloading = false;
            _this.notification.showInfo("Available records for facility successfully downloaded");
        }), catchError(function (err) {
            _this.loaderService.close();
            _this.notification.showError("There was an error downloading records; please try again");
            _this.downloading = false;
            return of();
        })).subscribe();
    };
    DatabaseSyncComponent.prototype.downloadBiometrics = function () {
        var _this = this;
        this.loaderService.open('Downloading biometric data from server. Please wait....');
        this.syncService.downloadBiometrics().subscribe();
        var id = setInterval(function () {
            _this.syncService.biometricDownloadCompleted().subscribe(function (res) {
                if (res) {
                    _this.loaderService.close();
                    clearInterval(id);
                }
            });
        }, 10000);
    };
    DatabaseSyncComponent.prototype.uploadBiometrics = function () {
        var _this = this;
        this.loaderService.open('Uploading biometric data to the server. Please wait....');
        this.syncService.uploadBiometrics().subscribe();
        var id = setInterval(function () {
            _this.syncService.biometricUploadCompleted().subscribe(function (res) {
                if (res) {
                    _this.loaderService.close();
                    clearInterval(id);
                }
            });
        }, 10000);
    };
    DatabaseSyncComponent.prototype.previousState = function () {
        window.history.back();
    };
    DatabaseSyncComponent.prototype.insertAt = function (array, index) {
        var elementsArray = [];
        for (var _i = 2; _i < arguments.length; _i++) {
            elementsArray[_i - 2] = arguments[_i];
        }
        array.splice.apply(array, __spread([index, 0], elementsArray));
    };
    DatabaseSyncComponent.ctorParameters = function () { return [
        { type: RxStompService },
        { type: SyncService },
        { type: NotificationService },
        { type: AppLoaderService }
    ]; };
    DatabaseSyncComponent = __decorate([
        Component({
            selector: 'database-sync',
            template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <ng-container *ngIf=\"syncing\">\n                <div class=\"full-width\">\n                    <mat-progress-bar class=\"full-width\" mode=\"indeterminate\"></mat-progress-bar>\n                </div>\n            </ng-container>\n            <mat-card-header>\n                <mat-card-title>Synchronize Database to Server</mat-card-title>\n                <button mat-icon-button [matMenuTriggerFor]=\"menu\" aria-label=\"Biometrics options\">\n                    <mat-icon>more_vert</mat-icon>\n                </button>\n                <mat-menu #menu=\"matMenu\">\n                    <button mat-menu-item (click)=\"uploadBiometrics()\" [disabled]=\"!serverContacted\">\n                        <mat-icon>file_upload</mat-icon>\n                        <span>Sync Biometrics</span>\n                    </button>\n                    <button mat-menu-item (click)=\"downloadBiometrics()\" [disabled]=\"!serverContacted\">\n                        <mat-icon>file_download</mat-icon>\n                        <span>Download Biometrics</span>\n                    </button>\n                </mat-menu>\n            </mat-card-header>\n            <mat-card-content>\n                <adf-card-view [properties]=\"properties\" [editable]=\"false\"></adf-card-view>\n                <mat-divider [inset]=\"true\"></mat-divider>\n                <mat-form-field class=\"full-width\">\n                    <mat-label>Synced Tables</mat-label>\n                    <textarea matInput disabled [value]='tables' rows=\"10\"></textarea>\n                </mat-form-field>\n                <mat-divider></mat-divider>\n                <mat-card-actions style=\"text-align: right !important;\">\n                    <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n                    <button mat-raised-button color='accent'\n                            (click)=\"downloadMobileRecords()\"\n                            [disabled]=\"downloading || !serverContacted\"\n                            type=\"button\">\n                        Download Mobile Records\n                    </button>\n                    <button mat-raised-button color='accent'\n                            (click)=\"downloadCparp()\"\n                            [disabled]=\"downloading || !serverContacted\"\n                            type=\"button\">\n                        Download CPARP Refill\n                    </button>\n                    <button mat-raised-button color='primary'\n                            (click)=\"sync()\"\n                            [disabled]=\"syncing || !serverContacted\"\n                            type=\"submit\">\n                        Upload to Server\n                    </button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
        })
    ], DatabaseSyncComponent);
    return DatabaseSyncComponent;
}());

var ɵ0$1 = {
    title: 'Database Sync',
    breadcrumb: 'DATABASE SYNC'
}, ɵ1$1 = {
    authorities: ['ROLE_ADMIN'],
    title: 'Database Sync',
    breadcrumb: 'DATABASE SYNC'
};
var ROUTES$1 = [
    {
        path: '',
        data: ɵ0$1,
        children: [
            {
                path: '',
                component: DatabaseSyncComponent,
                data: ɵ1$1,
            }
        ]
    }
];

var DatabaseSyncModule = /** @class */ (function () {
    function DatabaseSyncModule() {
    }
    DatabaseSyncModule = __decorate([
        NgModule({
            imports: [
                CommonModule,
                MaterialModule,
                RouterModule.forChild(ROUTES$1),
                CoreModule
            ],
            declarations: [
                DatabaseSyncComponent
            ]
        })
    ], DatabaseSyncModule);
    return DatabaseSyncModule;
}());

var moment$3 = moment_;
var ModuleManagementService = /** @class */ (function () {
    function ModuleManagementService(http, serverUrl) {
        this.http = http;
        this.serverUrl = serverUrl;
        this.resourceUrl = '';
        this.resourceUrl = serverUrl.SERVER_API_URL + '/api/modules-update';
    }
    ModuleManagementService.prototype.findById = function (id) {
        return this.http.get(this.resourceUrl + "/module/" + id, { observe: 'response' }).pipe(map(function (res) {
            res.body.buildTime = res.body.buildTime != null ? moment$3(res.body.buildTime) : null;
            return res;
        }));
    };
    ModuleManagementService.prototype.availableModules = function () {
        return this.http.get(this.resourceUrl + "/available-modules").pipe(map(function (res) {
            res.forEach(function (m) {
                m.buildTime = m.buildTime != null ? moment$3(m.buildTime) : null;
            });
            return res;
        }));
    };
    ModuleManagementService.prototype.uploadModule = function (form) {
        return this.http.post(this.resourceUrl + "/upload", form, { observe: 'response' });
    };
    ModuleManagementService.prototype.install = function (module) {
        return this.http.post(this.resourceUrl + "/save-update", module, { observe: 'response' });
    };
    ModuleManagementService.prototype.uninstall = function (module) {
        return this.http.post(this.resourceUrl + "/uninstall", module, { observe: 'response' });
    };
    ModuleManagementService.ctorParameters = function () { return [
        { type: HttpClient },
        { type: undefined, decorators: [{ type: Inject, args: [SERVER_API_URL_CONFIG,] }] }
    ]; };
    ModuleManagementService.ngInjectableDef = ɵɵdefineInjectable({ factory: function ModuleManagementService_Factory() { return new ModuleManagementService(ɵɵinject(HttpClient), ɵɵinject(SERVER_API_URL_CONFIG)); }, token: ModuleManagementService, providedIn: "root" });
    ModuleManagementService = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __param(1, Inject(SERVER_API_URL_CONFIG))
    ], ModuleManagementService);
    return ModuleManagementService;
}());

var ModuleListComponent = /** @class */ (function () {
    function ModuleListComponent(moduleManagementService, router, route) {
        this.moduleManagementService = moduleManagementService;
        this.router = router;
        this.route = route;
    }
    ModuleListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.moduleManagementService.availableModules().subscribe(function (res) { return _this.modules = res; });
    };
    ModuleListComponent.prototype.ngOnDestroy = function () {
    };
    ModuleListComponent.prototype.getProperties = function (module) {
        var properties = [];
        var description = new CardViewTextItemModel({
            label: 'Name',
            value: module.name,
            key: 'desc',
        });
        properties.push(description);
        var version = new CardViewTextItemModel({
            label: 'version',
            value: module.version,
            key: 'version',
        });
        properties.push(version);
        var active = new CardViewDatetimeItemModel({
            label: 'Build Time',
            value: module.buildTime,
            key: 'build',
            format: 'DD MMM, YYYY HH:MM'
        });
        properties.push(active);
        properties.push(new CardViewBoolItemModel({
            key: 'uninstall',
            label: 'Uninstall',
            value: module.uninstall
        }));
        return properties;
    };
    ModuleListComponent.prototype.update = function (module) {
        this.router.navigate(['.', module.id, 'update'], { relativeTo: this.route });
    };
    ModuleListComponent.prototype.uninstall = function (module) {
        var _this = this;
        this.moduleManagementService.uninstall(module).subscribe(function (res) {
            _this.moduleManagementService.availableModules().subscribe(function (res) { return _this.modules = res; });
        });
    };
    ModuleListComponent.prototype.previousState = function () {
        window.history.back();
    };
    ModuleListComponent.ctorParameters = function () { return [
        { type: ModuleManagementService },
        { type: Router },
        { type: ActivatedRoute }
    ]; };
    ModuleListComponent = __decorate([
        Component({
            selector: 'module-update-list',
            template: "<mat-card>\n    <mat-card-header>\n        Modules Update\n    </mat-card-header>\n    <mat-card-content>\n        <div class=\"row\" *ngIf=\"modules\">\n            <div class=\"col-sm-12 col-md-6 col-lg-4\"\n                 *ngFor=\"let module of modules\">\n                <mat-card class=\"\">\n                    <mat-card-content>\n                        <adf-card-view [properties]=\"getProperties(module)\"></adf-card-view>\n                    </mat-card-content>\n                    <mat-card-actions style=\"text-align: right !important;\">\n                        <button mat-raised-button color=\"accent\" type=\"button\" (click)=\"uninstall(module)\">Set for Uninstall</button>\n                        <button mat-raised-button type=\"button\" (click)=\"update(module)\">Update</button>\n                    </mat-card-actions>\n                </mat-card>\n            </div>\n        </div>\n        <mat-divider></mat-divider>\n        <mat-card-actions style=\"text-align: right !important;\">\n            <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n        </mat-card-actions>\n    </mat-card-content>\n</mat-card>\n<div class=\"fab-container\">\n    <button mat-fab\n            [matTooltip]=\"'Add Update'\"\n            [routerLink]=\"['new']\">\n        <mat-icon>add</mat-icon>\n    </button>\n</div>\n"
        })
    ], ModuleListComponent);
    return ModuleListComponent;
}());

var ModuleUpdateComponent = /** @class */ (function () {
    function ModuleUpdateComponent(notification, router, service, loaderService, route) {
        this.notification = notification;
        this.router = router;
        this.service = service;
        this.loaderService = loaderService;
        this.route = route;
        this.properties = [];
        this.update = false;
        this.uploaded = false;
    }
    ModuleUpdateComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.route.data.subscribe(function (_a) {
            var module = _a.module;
            _this.module = !!module && module.body ? module.body : module;
            _this.update = !!_this.module;
        });
    };
    ModuleUpdateComponent.prototype.uploadEvent = function (file) {
        var _this = this;
        this.uploaded = false;
        var formData = new FormData();
        formData.append('file', file);
        this.loaderService.open('Uploading module: please wait...');
        this.service.uploadModule(formData)
            .subscribe(function (res) {
            _this.loaderService.close();
            _this.uploaded = true;
            if (res.ok) {
                _this.module = res.body;
                _this.properties = [];
                var name_1 = new CardViewTextItemModel({
                    label: 'Name',
                    value: _this.module.name,
                    key: 'name',
                });
                _this.properties.push(name_1);
                var version = new CardViewTextItemModel({
                    label: 'Version',
                    value: _this.module.version,
                    key: 'version',
                });
                _this.properties.push(version);
                var buildTime = new CardViewDatetimeItemModel({
                    label: 'Build Time',
                    value: _this.module.buildTime,
                    key: 'bp',
                    format: 'DD MMM, YYYY HH:MM'
                });
                _this.properties.push(buildTime);
            }
            else {
                _this.notification.showError('Module upload failed');
            }
        }, (function (error) { return _this.notification.showError('Module upload failed: ' + error.text); }));
    };
    ModuleUpdateComponent.prototype.install = function () {
        var _this = this;
        this.loaderService.open('Saving module update: please wait...');
        this.service.install(this.module).subscribe(function (res) {
            _this.loaderService.close();
            _this.router.navigate(['..'], { relativeTo: _this.route });
        }, function (err) {
            _this.loaderService.close();
            _this.notification.showError('Could not save module update: ' + err.text);
        });
    };
    ModuleUpdateComponent.prototype.selectEvent = function (files) {
    };
    ModuleUpdateComponent.prototype.cancelEvent = function () {
        this.files = undefined;
    };
    ModuleUpdateComponent.ctorParameters = function () { return [
        { type: NotificationService },
        { type: Router },
        { type: ModuleManagementService },
        { type: AppLoaderService },
        { type: ActivatedRoute }
    ]; };
    ModuleUpdateComponent = __decorate([
        Component({
            selector: 'module-update-update',
            template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <mat-card-header *ngIf=\"update\">\n                Updating {{module.name}}\n            </mat-card-header>\n            <mat-card-content>\n                <td-file-upload #singleFileUpload [(ngModel)]=\"files\"\n                                (select)=\"selectEvent($event)\"\n                                (upload)=\"uploadEvent($event)\" (cancel)=\"cancelEvent()\"\n                                accept=\".jar\" required>\n                    <mat-icon>file_upload</mat-icon>\n                    <span>{{ singleFileUpload.value?.name }}</span>\n                    <ng-template td-file-input-label>\n                        <mat-icon>attach_file</mat-icon>\n                        <span>Choose a file...</span>\n                        <span [hidden]=\"!singleFileUpload?.required\">*</span>\n                    </ng-template>\n                </td-file-upload>\n            </mat-card-content>\n        </mat-card>\n        <mat-card *ngIf=\"module\">\n            <mat-card-title>\n                Module Details\n            </mat-card-title>\n            <mat-card-content>\n                <adf-card-view [properties]=\"properties\"></adf-card-view>\n                <mat-card-actions>\n                    <button mat-raised-button color=\"primary\" [disabled]=\"!uploaded\" (click)=\"install()\">Save</button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
        })
    ], ModuleUpdateComponent);
    return ModuleUpdateComponent;
}());

var ModuleResolve = /** @class */ (function () {
    function ModuleResolve(service) {
        this.service = service;
    }
    ModuleResolve.prototype.resolve = function (route, state) {
        var id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.findById(id).pipe(filter(function (response) { return response.ok; }), map(function (patient) { return patient.body; }));
        }
        return of({});
    };
    ModuleResolve.ctorParameters = function () { return [
        { type: ModuleManagementService }
    ]; };
    ModuleResolve = __decorate([
        Injectable()
    ], ModuleResolve);
    return ModuleResolve;
}());
var ɵ0$2 = {
    authorities: ['ROLE_MODULE_MANAGEMENT'],
    title: 'Modules Update List',
    breadcrumb: 'MODULES UPDATE LIST'
}, ɵ1$2 = {
    title: 'Modules Update List',
    breadcrumb: 'MODULES UPDATE LIST'
}, ɵ2 = {
    title: 'Upload Module Update',
    breadcrumb: 'UPLOAD MODULE UPDATE'
}, ɵ3 = {
    title: 'Upload Module Update',
    breadcrumb: 'UPLOAD MODULE UPDATE'
};
var ROUTES$2 = [
    {
        path: '',
        data: ɵ0$2,
        canActivate: [UserRouteAccessService],
        children: [
            {
                path: '',
                component: ModuleListComponent,
                data: ɵ1$2
            },
            {
                path: 'new',
                component: ModuleUpdateComponent,
                data: ɵ2
            },
            {
                path: ':id/update',
                component: ModuleUpdateComponent,
                resolve: {
                    module: ModuleResolve
                },
                data: ɵ3
            }
        ]
    }
];

var ModulesUpdateModule = /** @class */ (function () {
    function ModulesUpdateModule() {
    }
    ModulesUpdateModule = __decorate([
        NgModule({
            imports: [
                CommonModule,
                RouterModule.forChild(ROUTES$2),
                CoreModule,
                MaterialModule,
                CovalentCommonModule,
                CovalentFileModule,
                LamisSharedModule
            ],
            declarations: [
                ModuleListComponent,
                ModuleUpdateComponent
            ],
            providers: [
                ModuleResolve
            ]
        })
    ], ModulesUpdateModule);
    return ModulesUpdateModule;
}());

var UpdatesManagementModule = /** @class */ (function () {
    function UpdatesManagementModule() {
    }
    UpdatesManagementModule = __decorate([
        NgModule({
            imports: [
                CommonModule,
                CoreModule,
                MaterialModule
            ],
        })
    ], UpdatesManagementModule);
    return UpdatesManagementModule;
}());

var UploadReportComponent = /** @class */ (function () {
    function UploadReportComponent(service, appLoader, notification) {
        this.service = service;
        this.appLoader = appLoader;
        this.notification = notification;
        this.running = false;
    }
    UploadReportComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.service.states().subscribe(function (res) { return _this.states = res; });
    };
    UploadReportComponent.prototype.previousState = function () {
        window.history.back();
    };
    UploadReportComponent.prototype.generate = function () {
        var _this = this;
        this.running = true;
        this.appLoader.open('Generating report; please wait...');
        this.service.uploadReport(this.state.id, this.format).subscribe(function (res) {
            _this.appLoader.close();
            _this.running = false;
            var format = _this.format === 0 ? 'pdf' : 'xlsx';
            var file = new File([res], _this.state.name + " Database Upload_Biometric Coverage Report." + format, { type: 'application/octet-stream' });
            saveAs(file);
        }, function (err) {
            _this.appLoader.close();
            _this.running = false;
            _this.notification.showError("An error occurred generating report: " + err.message);
        });
    };
    UploadReportComponent.ctorParameters = function () { return [
        { type: SyncService },
        { type: AppLoaderService },
        { type: NotificationService }
    ]; };
    UploadReportComponent = __decorate([
        Component({
            selector: 'upload-report',
            template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <mat-card-header>\n                <mat-card-title>\n                    Database Upload/ Biometric Coverage Report\n                </mat-card-title>\n            </mat-card-header>\n            <mat-card-content>\n                <div class=\"row\">\n                    <div class=\"col-md-6\">\n                        <mat-form-field class=\"full-width\">\n                            <mat-label>State</mat-label>\n                            <mat-select [(ngModel)]=\"state\" name=\"state\">\n                                <mat-option></mat-option>\n                                <mat-option *ngFor=\"let c of states\" [value]=\"c\">{{c.name}}\n                                </mat-option>\n                            </mat-select>\n                        </mat-form-field>\n                    </div>\n                    <div class=\"col-md-6\">\n                        <mat-form-field class=\"full-width\">\n                            <mat-label>Format</mat-label>\n                            <mat-select [(ngModel)]=\"format\" name=\"format\">\n                                <mat-option [value]=\"0\">PDF</mat-option>\n                                <mat-option [value]=\"1\">Excel</mat-option>\n                            </mat-select>\n                        </mat-form-field>\n                    </div>\n                </div>\n                <mat-card-actions style=\"text-align: right !important;\">\n                    <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n                    <button mat-raised-button color='primary'\n                            (click)=\"generate()\"\n                            [disabled]=\"!state\"\n                            type=\"button\">\n                        Generate\n                    </button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
        })
    ], UploadReportComponent);
    return UploadReportComponent;
}());

var ɵ0$3 = {
    title: 'Database Upload Report',
    breadcrumb: 'DATABASE UPLOAD REPORT'
}, ɵ1$3 = {
    authorities: ['ROLE_ADMIN'],
    title: 'Database Upload Report',
    breadcrumb: 'DATABASE UPLOAD REPORT'
};
var ROUTES$3 = [
    {
        path: '',
        data: ɵ0$3,
        children: [
            {
                path: '',
                component: UploadReportComponent,
                data: ɵ1$3,
            }
        ]
    }
];
var UploadReportModule = /** @class */ (function () {
    function UploadReportModule() {
    }
    UploadReportModule = __decorate([
        NgModule({
            declarations: [
                UploadReportComponent
            ],
            imports: [
                CommonModule,
                RouterModule.forChild(ROUTES$3),
                MaterialModule,
                FormsModule
            ]
        })
    ], UploadReportModule);
    return UploadReportModule;
}());

/*
 * Public API Surface of Clinic
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DatabaseSyncModule, ModulesUpdateModule, ROUTES$3 as ROUTES, UpdatesManagementModule, UpdatesModule, UploadReportModule, ɵ0$3 as ɵ0, ɵ1$3 as ɵ1, ModulesUpdateComponent as ɵa, ModulesUpdateService as ɵb, SyncService as ɵc, ROUTES as ɵd, modules as ɵe, MaterialModule as ɵf, ROUTES$1 as ɵg, DatabaseSyncComponent as ɵh, ModuleResolve as ɵi, ROUTES$2 as ɵj, ModuleListComponent as ɵk, ModuleManagementService as ɵl, ModuleUpdateComponent as ɵm, UploadReportComponent as ɵn };
//# sourceMappingURL=lamis-database.js.map
