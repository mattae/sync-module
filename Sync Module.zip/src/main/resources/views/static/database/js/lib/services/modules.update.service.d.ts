import { HttpClient } from '@angular/common/http';
import { ServerApiUrlConfig } from '@lamis/web-core';
import { ModuleUpdate } from '../model/module.model';
export declare class ModulesUpdateService {
    protected http: HttpClient;
    private serverUrl;
    resourceUrl: string;
    constructor(http: HttpClient, serverUrl: ServerApiUrlConfig);
    installUpdates(): import("rxjs").Observable<ModuleUpdate[]>;
    availableUpdates(): import("rxjs").Observable<ModuleUpdate[]>;
    checkForUpdates(): import("rxjs").Observable<Object>;
    lastHeartbeat(): import("rxjs").Observable<Object>;
}
