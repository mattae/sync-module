import { HttpClient } from '@angular/common/http';
import { ServerApiUrlConfig } from '@lamis/web-core';
export declare class SyncService {
    protected http: HttpClient;
    private serverUrl;
    resourceUrl: string;
    constructor(http: HttpClient, serverUrl: ServerApiUrlConfig);
    sync(): import("rxjs").Observable<Object>;
    downloadBiometrics(): import("rxjs").Observable<Object>;
    uploadBiometrics(): import("rxjs").Observable<Object>;
    biometricDownloadCompleted(): import("rxjs").Observable<boolean>;
    biometricUploadCompleted(): import("rxjs").Observable<boolean>;
    downloadCparp(facilityId: number): import("rxjs").Observable<Object>;
    downloadMobileRecords(): import("rxjs").Observable<Object>;
    init(): import("rxjs").Observable<Object>;
    states(): import("rxjs").Observable<any[]>;
    getActiveFacility(): import("rxjs").Observable<any>;
    destroy(): import("rxjs").Observable<Object>;
    uploadReport(stateId: any, format: number): import("rxjs").Observable<Blob>;
}
