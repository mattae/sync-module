import { NotificationService } from '@alfresco/adf-core';
import { OnInit } from '@angular/core';
import { AppLoaderService } from '@lamis/web-core';
import { SyncService } from '../../services/sync.service';
export declare class UploadReportComponent implements OnInit {
    private service;
    private appLoader;
    private notification;
    running: boolean;
    state: any;
    format: number;
    states: any[];
    constructor(service: SyncService, appLoader: AppLoaderService, notification: NotificationService);
    ngOnInit(): void;
    previousState(): void;
    generate(): void;
}
