import { OnDestroy, OnInit } from '@angular/core';
import { CardViewItem } from '@alfresco/adf-core';
import { ModuleUpdate } from '../../model/module.model';
import { ModulesUpdateService } from '../../services/modules.update.service';
import { RxStompService } from '@stomp/ng2-stompjs';
import { SyncService } from '../../services/sync.service';
import { Subscription } from 'rxjs';
export declare class ModulesUpdateComponent implements OnInit, OnDestroy {
    private service;
    private stompService;
    private syncService;
    statusSubscription: Subscription;
    modules: ModuleUpdate[];
    isUpdating: boolean;
    installed: boolean;
    completeChecking: boolean;
    checked: boolean;
    properties: Array<CardViewItem>;
    serverContacted: boolean;
    constructor(service: ModulesUpdateService, stompService: RxStompService, syncService: SyncService);
    ngOnInit(): void;
    ngOnDestroy(): void;
    checkForUpdates(): void;
    getProperties(module: ModuleUpdate): Array<CardViewItem>;
    updateModules(): void;
    previousState(): void;
}
