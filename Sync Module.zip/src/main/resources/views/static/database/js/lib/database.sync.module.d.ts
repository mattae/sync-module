export declare class DatabaseSyncModule {
}
