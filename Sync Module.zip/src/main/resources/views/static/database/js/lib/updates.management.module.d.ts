export declare class UpdatesManagementModule {
}
