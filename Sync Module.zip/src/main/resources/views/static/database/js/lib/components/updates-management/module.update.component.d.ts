import { OnInit } from '@angular/core';
import { ModuleUpdate } from '../../model/module.model';
import { CardViewItem, NotificationService } from '@alfresco/adf-core';
import { ActivatedRoute, Router } from '@angular/router';
import { AppLoaderService } from '@lamis/web-core';
import { ModuleManagementService } from '../../services/module.management.service';
export declare class ModuleUpdateComponent implements OnInit {
    private notification;
    private router;
    private service;
    private loaderService;
    private route;
    module: ModuleUpdate;
    files: File | FileList;
    properties: Array<CardViewItem>;
    update: boolean;
    uploaded: boolean;
    constructor(notification: NotificationService, router: Router, service: ModuleManagementService, loaderService: AppLoaderService, route: ActivatedRoute);
    ngOnInit(): void;
    uploadEvent(file: File): void;
    install(): void;
    selectEvent(files: File): void;
    cancelEvent(): void;
}
