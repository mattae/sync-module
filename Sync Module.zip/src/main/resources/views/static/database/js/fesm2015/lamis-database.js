import { __decorate, __param } from 'tslib';
import { CardViewDatetimeItemModel, CardViewTextItemModel, CoreModule, CardViewBoolItemModel, NotificationService } from '@alfresco/adf-core';
import { CommonModule } from '@angular/common';
import { Inject, ɵɵdefineInjectable, ɵɵinject, Injectable, Component, NgModule } from '@angular/core';
import { MatInputModule, MatIconModule, MatCardModule, MatSelectModule, MatButtonModule, MatProgressBarModule, MatTableModule, MatListModule, MatAutocompleteModule, MatCheckboxModule, MatChipsModule, MatDatepickerModule, MatDialogModule, MatGridListModule, MatNativeDateModule, MatOptionModule, MatProgressSpinnerModule, MatRadioModule, MatRippleModule, MatSlideToggleModule, MatTabsModule, MatMenuModule, MatSidenavModule, MatSnackBarModule, MatToolbarModule, MatTooltipModule } from '@angular/material';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { CovalentMessageModule, CovalentDialogsModule, CovalentCommonModule, CovalentFileModule } from '@covalent/core';
import { HttpClient } from '@angular/common/http';
import { SERVER_API_URL_CONFIG, MatDateFormatModule, AppLoaderService, UserRouteAccessService, LamisSharedModule } from '@lamis/web-core';
import { map, catchError, filter } from 'rxjs/operators';
import * as moment_ from 'moment';
import { RxStompService } from '@stomp/ng2-stompjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomFormsModule } from 'ng2-validation';
import { MatDatetimepickerModule, MatNativeDatetimeModule } from '@mat-datetimepicker/core';
import { of } from 'rxjs';
import { saveAs } from 'file-saver';

const moment = moment_;
let ModulesUpdateService = class ModulesUpdateService {
    constructor(http, serverUrl) {
        this.http = http;
        this.serverUrl = serverUrl;
        this.resourceUrl = '';
        this.resourceUrl = serverUrl.SERVER_API_URL + '/api/modules-update';
    }
    installUpdates() {
        return this.http.get(`${this.resourceUrl}/install-updates`);
    }
    availableUpdates() {
        return this.http.get(`${this.resourceUrl}/available-modules`);
    }
    checkForUpdates() {
        return this.http.get(`${this.resourceUrl}/check-for-updates`);
    }
    lastHeartbeat() {
        return this.http.get(`${this.resourceUrl}/last-heartbeat`).pipe(map(res => {
            res = res != null ? moment(res, moment.ISO_8601) : null;
            return res;
        }));
    }
};
ModulesUpdateService.ctorParameters = () => [
    { type: HttpClient },
    { type: undefined, decorators: [{ type: Inject, args: [SERVER_API_URL_CONFIG,] }] }
];
ModulesUpdateService.ngInjectableDef = ɵɵdefineInjectable({ factory: function ModulesUpdateService_Factory() { return new ModulesUpdateService(ɵɵinject(HttpClient), ɵɵinject(SERVER_API_URL_CONFIG)); }, token: ModulesUpdateService, providedIn: "root" });
ModulesUpdateService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __param(1, Inject(SERVER_API_URL_CONFIG))
], ModulesUpdateService);

let SyncService = class SyncService {
    constructor(http, serverUrl) {
        this.http = http;
        this.serverUrl = serverUrl;
        this.resourceUrl = '';
        this.resourceUrl = serverUrl.SERVER_API_URL + '/api/database-sync';
    }
    sync() {
        return this.http.get(`${this.resourceUrl}/sync`);
    }
    downloadBiometrics() {
        return this.http.get(`${this.resourceUrl}/download-biometrics`);
    }
    uploadBiometrics() {
        return this.http.get(`${this.resourceUrl}/upload-biometrics`);
    }
    biometricDownloadCompleted() {
        return this.http.get(`${this.resourceUrl}/biometric-download-completed`);
    }
    biometricUploadCompleted() {
        return this.http.get(`${this.resourceUrl}/biometric-upload-completed`);
    }
    downloadCparp(facilityId) {
        return this.http.get(`${this.resourceUrl}/cparp/update/${facilityId}`);
    }
    downloadMobileRecords() {
        return this.http.get(`${this.resourceUrl}/download-records`);
    }
    init() {
        return this.http.get(`${this.resourceUrl}/init`);
    }
    states() {
        return this.http.get(`${this.resourceUrl}/states`);
    }
    getActiveFacility() {
        return this.http.get('/api/facilities/active');
    }
    destroy() {
        return this.http.get(`${this.resourceUrl}/destroy`);
    }
    uploadReport(stateId, format) {
        return this.http.get(`${this.resourceUrl}/upload-report?stateId=${stateId}&format=${format}`, { responseType: 'blob' });
    }
};
SyncService.ctorParameters = () => [
    { type: HttpClient },
    { type: undefined, decorators: [{ type: Inject, args: [SERVER_API_URL_CONFIG,] }] }
];
SyncService.ngInjectableDef = ɵɵdefineInjectable({ factory: function SyncService_Factory() { return new SyncService(ɵɵinject(HttpClient), ɵɵinject(SERVER_API_URL_CONFIG)); }, token: SyncService, providedIn: "root" });
SyncService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __param(1, Inject(SERVER_API_URL_CONFIG))
], SyncService);

const moment$1 = moment_;
let ModulesUpdateComponent = class ModulesUpdateComponent {
    constructor(service, stompService, syncService) {
        this.service = service;
        this.stompService = stompService;
        this.syncService = syncService;
        this.modules = [];
        this.isUpdating = false;
        this.installed = false;
        this.completeChecking = false;
        this.checked = false;
        this.properties = [];
        this.serverContacted = false;
    }
    ngOnInit() {
        this.statusSubscription = this.stompService.watch('/topic/update/download/completed').subscribe((msg) => {
            this.completeChecking = msg.body === 'true';
            this.checked = true;
            this.service.availableUpdates().subscribe(res => this.modules = res);
        });
        this.service.availableUpdates().subscribe(res => this.modules = res);
        this.service.lastHeartbeat().subscribe(res => {
            this.serverContacted = !!res;
            this.properties = [];
            this.properties.push(new CardViewDatetimeItemModel({
                key: 'hb',
                label: 'Last Contact with Server',
                value: res,
                format: 'DD MMM, YYYY HH:MM'
            }));
        });
    }
    ngOnDestroy() {
        this.statusSubscription.unsubscribe();
    }
    checkForUpdates() {
        this.service.checkForUpdates().subscribe(res => {
            this.checked = true;
            this.completeChecking = false;
        });
    }
    getProperties(module) {
        const properties = [];
        const description = new CardViewTextItemModel({
            label: 'Name',
            value: module.name,
            key: 'desc',
        });
        properties.push(description);
        const version = new CardViewTextItemModel({
            label: 'version',
            value: module.version,
            key: 'version',
        });
        properties.push(version);
        const active = new CardViewDatetimeItemModel({
            label: 'Build Time',
            value: moment$1(module.buildTime),
            key: 'active',
            format: 'DD MMM, YYYY HH:MM'
        });
        properties.push(active);
        return properties;
    }
    updateModules() {
        this.isUpdating = true;
        this.installed = false;
        this.service.installUpdates().subscribe(res => {
            this.modules = res;
            this.isUpdating = false;
            this.installed = true;
            this.service.availableUpdates().subscribe(res => this.modules = res);
        });
    }
    previousState() {
        window.history.back();
    }
};
ModulesUpdateComponent.ctorParameters = () => [
    { type: ModulesUpdateService },
    { type: RxStompService },
    { type: SyncService }
];
ModulesUpdateComponent = __decorate([
    Component({
        selector: 'modules-update',
        template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <mat-card-header *ngIf=\"installed\">\n                <mat-card-title>\n                    <p style=\"color: green\">\n                        Updates installed; please restart service or system\n                    </p>\n                </mat-card-title>\n            </mat-card-header>\n            <ng-container *ngIf=\"!completeChecking && checked\">\n                <div class=\"full-width\">\n                    <mat-progress-bar class=\"full-width\" mode=\"indeterminate\"></mat-progress-bar>\n                </div>\n            </ng-container>\n            <mat-card-content>\n                <adf-card-view [properties]=\"properties\" editable=\"false\"></adf-card-view>\n                <mat-divider [inset]=\"true\"></mat-divider>\n                <div class=\"row\" *ngIf=\"modules\">\n                    <div class=\"col-sm-12 col-md-6 col-lg-4\"\n                         *ngFor=\"let module of modules\">\n                        <mat-card class=\"\">\n                            <mat-card-content>\n                                <adf-card-view [properties]=\"getProperties(module)\"></adf-card-view>\n                            </mat-card-content>\n                        </mat-card>\n                    </div>\n                </div>\n                <adf-empty-content\n                        *ngIf=\"!modules.length && checked && completeChecking\"\n                        icon=\"group\"\n                        [title]=\"'No updates available'\">\n                </adf-empty-content>\n                <mat-divider></mat-divider>\n                <mat-card-actions style=\"text-align: right !important;\">\n                    <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n                    <button mat-raised-button color='accent'\n                            (click)=\"checkForUpdates()\"\n                            [disabled]=\"!completeChecking && checked || isUpdating || !serverContacted\"\n                            type=\"button\">\n                        Check for Updates\n                    </button>\n                    <button mat-raised-button color='primary' *ngIf=\"!!modules.length\"\n                            (click)=\"updateModules()\"\n                            [disabled]=\"!completeChecking && checked || isUpdating\"\n                            type=\"button\">\n                        Install Updates\n                    </button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
    })
], ModulesUpdateComponent);

const ɵ0 = {
    title: 'Module Updates',
    breadcrumb: 'MODULE UPDATES'
}, ɵ1 = {
    authorities: ['ROLE_ADMIN'],
    title: 'Module Updates',
    breadcrumb: 'MODULE UPDATES'
};
const ROUTES = [
    {
        path: '',
        data: ɵ0,
        children: [
            {
                path: '',
                component: ModulesUpdateComponent,
                data: ɵ1,
            }
        ]
    }
];

let UpdatesModule = class UpdatesModule {
};
UpdatesModule = __decorate([
    NgModule({
        declarations: [
            ModulesUpdateComponent
        ],
        imports: [
            CommonModule,
            MatInputModule,
            MatIconModule,
            MatCardModule,
            MatSelectModule,
            MatButtonModule,
            RouterModule.forChild(ROUTES),
            MatProgressBarModule,
            FormsModule,
            CovalentMessageModule,
            CovalentDialogsModule,
            MatTableModule,
            MatListModule,
            CoreModule,
            ReactiveFormsModule,
            MatDateFormatModule,
            CustomFormsModule
        ],
        exports: [],
        entryComponents: [],
        providers: []
    })
], UpdatesModule);

/*!
 * @license
 * Copyright 2016 Alfresco Software, Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function modules() {
    return [
        MatAutocompleteModule, MatButtonModule, MatCardModule, MatCheckboxModule,
        MatChipsModule, MatDatepickerModule, MatDialogModule, MatGridListModule, MatIconModule,
        MatInputModule, MatListModule, MatNativeDateModule, MatOptionModule, MatProgressSpinnerModule, MatRadioModule,
        MatRippleModule, MatSelectModule, MatSlideToggleModule, MatTableModule, MatTabsModule,
        MatMenuModule, MatProgressBarModule, MatSidenavModule, MatSnackBarModule, MatToolbarModule,
        MatTooltipModule, MatDatetimepickerModule, MatNativeDatetimeModule
    ];
}
let MaterialModule = class MaterialModule {
};
MaterialModule = __decorate([
    NgModule({
        imports: modules(),
        exports: modules()
    })
], MaterialModule);

const moment$2 = moment_;
let DatabaseSyncComponent = class DatabaseSyncComponent {
    constructor(stompService, syncService, notification, loaderService) {
        this.stompService = stompService;
        this.syncService = syncService;
        this.notification = notification;
        this.loaderService = loaderService;
        this.syncing = false;
        this.downloading = false;
        this.serverContacted = false;
        this.tables = '';
        this.properties = [];
    }
    ngOnInit() {
        this.syncService.getActiveFacility().subscribe(res => this.facility = res);
        this.properties = [];
        this.statusSubscription = this.stompService.watch('/topic/sync/server-status').subscribe((msg) => {
            this.properties = this.properties.filter(i => i.key !== 'server');
            this.insertAt(this.properties, 0, (new CardViewDatetimeItemModel({
                key: 'server',
                value: msg.body && moment$2(msg.body, moment$2.ISO_8601) || null,
                label: 'Last contact with Server',
                format: 'DD MMM, YYYY HH:MM'
            })));
        });
        this.statusSubscription = this.stompService.watch('/topic/sync/sync-status').subscribe((msg) => {
            this.properties = this.properties.filter(i => i.key !== 'sync');
            this.insertAt(this.properties, 1, (new CardViewDatetimeItemModel({
                key: 'sync',
                value: msg.body && moment$2(msg.body, moment$2.ISO_8601) || null,
                label: 'Last Sync to Server',
                format: 'DD MMM, YYYY HH:MM'
            })));
        });
        this.syncSubscription = this.stompService.watch('/topic/sync/upload-status/completed').subscribe((msg) => {
            this.syncing = msg.body === 'false';
            this.properties = this.properties.filter(i => i.key !== 'status');
            this.properties.push(new CardViewBoolItemModel({
                key: 'status',
                value: msg.body === 'true',
                label: 'Upload Completed',
            }));
        });
        this.tableSubscription = this.stompService.watch('/topic/sync/table-status').subscribe((msg) => {
            this.tables = msg.body;
        });
        this.serverSubscription = this.stompService.watch('/topic/sync/server').subscribe((msg) => {
            this.serverContacted = !!msg.body;
        });
        this.syncService.init().subscribe();
    }
    ngOnDestroy() {
        this.statusSubscription.unsubscribe();
        this.tableSubscription.unsubscribe();
        this.syncSubscription.unsubscribe();
        this.syncService.destroy().subscribe();
        this.serverSubscription.unsubscribe();
    }
    sync() {
        this.syncing = true;
        this.syncService.sync().subscribe();
    }
    downloadCparp() {
        this.downloading = true;
        this.loaderService.open('Downloading records, please wait...');
        this.syncService.downloadCparp(this.facility.id).pipe(map(res => {
            this.loaderService.close();
            this.downloading = false;
            this.notification.showInfo("Available records for facility successfully downloaded");
        }), catchError((err) => {
            this.loaderService.close();
            this.notification.showError("There was an error downloading records; please try again");
            this.downloading = false;
            return of();
        })).subscribe();
    }
    downloadMobileRecords() {
        this.downloading = true;
        this.loaderService.open('Downloading records, please wait...');
        this.syncService.downloadMobileRecords().pipe(map(res => {
            this.loaderService.close();
            this.downloading = false;
            this.notification.showInfo("Available records for facility successfully downloaded");
        }), catchError((err) => {
            this.loaderService.close();
            this.notification.showError("There was an error downloading records; please try again");
            this.downloading = false;
            return of();
        })).subscribe();
    }
    downloadBiometrics() {
        this.loaderService.open('Downloading biometric data from server. Please wait....');
        this.syncService.downloadBiometrics().subscribe();
        let id = setInterval(() => {
            this.syncService.biometricDownloadCompleted().subscribe(res => {
                if (res) {
                    this.loaderService.close();
                    clearInterval(id);
                }
            });
        }, 10000);
    }
    uploadBiometrics() {
        this.loaderService.open('Uploading biometric data to the server. Please wait....');
        this.syncService.uploadBiometrics().subscribe();
        let id = setInterval(() => {
            this.syncService.biometricUploadCompleted().subscribe(res => {
                if (res) {
                    this.loaderService.close();
                    clearInterval(id);
                }
            });
        }, 10000);
    }
    previousState() {
        window.history.back();
    }
    insertAt(array, index, ...elementsArray) {
        array.splice(index, 0, ...elementsArray);
    }
};
DatabaseSyncComponent.ctorParameters = () => [
    { type: RxStompService },
    { type: SyncService },
    { type: NotificationService },
    { type: AppLoaderService }
];
DatabaseSyncComponent = __decorate([
    Component({
        selector: 'database-sync',
        template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <ng-container *ngIf=\"syncing\">\n                <div class=\"full-width\">\n                    <mat-progress-bar class=\"full-width\" mode=\"indeterminate\"></mat-progress-bar>\n                </div>\n            </ng-container>\n            <mat-card-header>\n                <mat-card-title>Synchronize Database to Server</mat-card-title>\n                <button mat-icon-button [matMenuTriggerFor]=\"menu\" aria-label=\"Biometrics options\">\n                    <mat-icon>more_vert</mat-icon>\n                </button>\n                <mat-menu #menu=\"matMenu\">\n                    <button mat-menu-item (click)=\"uploadBiometrics()\" [disabled]=\"!serverContacted\">\n                        <mat-icon>file_upload</mat-icon>\n                        <span>Sync Biometrics</span>\n                    </button>\n                    <button mat-menu-item (click)=\"downloadBiometrics()\" [disabled]=\"!serverContacted\">\n                        <mat-icon>file_download</mat-icon>\n                        <span>Download Biometrics</span>\n                    </button>\n                </mat-menu>\n            </mat-card-header>\n            <mat-card-content>\n                <adf-card-view [properties]=\"properties\" [editable]=\"false\"></adf-card-view>\n                <mat-divider [inset]=\"true\"></mat-divider>\n                <mat-form-field class=\"full-width\">\n                    <mat-label>Synced Tables</mat-label>\n                    <textarea matInput disabled [value]='tables' rows=\"10\"></textarea>\n                </mat-form-field>\n                <mat-divider></mat-divider>\n                <mat-card-actions style=\"text-align: right !important;\">\n                    <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n                    <button mat-raised-button color='accent'\n                            (click)=\"downloadMobileRecords()\"\n                            [disabled]=\"downloading || !serverContacted\"\n                            type=\"button\">\n                        Download Mobile Records\n                    </button>\n                    <button mat-raised-button color='accent'\n                            (click)=\"downloadCparp()\"\n                            [disabled]=\"downloading || !serverContacted\"\n                            type=\"button\">\n                        Download CPARP Refill\n                    </button>\n                    <button mat-raised-button color='primary'\n                            (click)=\"sync()\"\n                            [disabled]=\"syncing || !serverContacted\"\n                            type=\"submit\">\n                        Upload to Server\n                    </button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
    })
], DatabaseSyncComponent);

const ɵ0$1 = {
    title: 'Database Sync',
    breadcrumb: 'DATABASE SYNC'
}, ɵ1$1 = {
    authorities: ['ROLE_ADMIN'],
    title: 'Database Sync',
    breadcrumb: 'DATABASE SYNC'
};
const ROUTES$1 = [
    {
        path: '',
        data: ɵ0$1,
        children: [
            {
                path: '',
                component: DatabaseSyncComponent,
                data: ɵ1$1,
            }
        ]
    }
];

let DatabaseSyncModule = class DatabaseSyncModule {
};
DatabaseSyncModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            MaterialModule,
            RouterModule.forChild(ROUTES$1),
            CoreModule
        ],
        declarations: [
            DatabaseSyncComponent
        ]
    })
], DatabaseSyncModule);

const moment$3 = moment_;
let ModuleManagementService = class ModuleManagementService {
    constructor(http, serverUrl) {
        this.http = http;
        this.serverUrl = serverUrl;
        this.resourceUrl = '';
        this.resourceUrl = serverUrl.SERVER_API_URL + '/api/modules-update';
    }
    findById(id) {
        return this.http.get(`${this.resourceUrl}/module/${id}`, { observe: 'response' }).pipe(map(res => {
            res.body.buildTime = res.body.buildTime != null ? moment$3(res.body.buildTime) : null;
            return res;
        }));
    }
    availableModules() {
        return this.http.get(`${this.resourceUrl}/available-modules`).pipe(map(res => {
            res.forEach(m => {
                m.buildTime = m.buildTime != null ? moment$3(m.buildTime) : null;
            });
            return res;
        }));
    }
    uploadModule(form) {
        return this.http.post(`${this.resourceUrl}/upload`, form, { observe: 'response' });
    }
    install(module) {
        return this.http.post(`${this.resourceUrl}/save-update`, module, { observe: 'response' });
    }
    uninstall(module) {
        return this.http.post(`${this.resourceUrl}/uninstall`, module, { observe: 'response' });
    }
};
ModuleManagementService.ctorParameters = () => [
    { type: HttpClient },
    { type: undefined, decorators: [{ type: Inject, args: [SERVER_API_URL_CONFIG,] }] }
];
ModuleManagementService.ngInjectableDef = ɵɵdefineInjectable({ factory: function ModuleManagementService_Factory() { return new ModuleManagementService(ɵɵinject(HttpClient), ɵɵinject(SERVER_API_URL_CONFIG)); }, token: ModuleManagementService, providedIn: "root" });
ModuleManagementService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __param(1, Inject(SERVER_API_URL_CONFIG))
], ModuleManagementService);

let ModuleListComponent = class ModuleListComponent {
    constructor(moduleManagementService, router, route) {
        this.moduleManagementService = moduleManagementService;
        this.router = router;
        this.route = route;
    }
    ngOnInit() {
        this.moduleManagementService.availableModules().subscribe(res => this.modules = res);
    }
    ngOnDestroy() {
    }
    getProperties(module) {
        const properties = [];
        const description = new CardViewTextItemModel({
            label: 'Name',
            value: module.name,
            key: 'desc',
        });
        properties.push(description);
        const version = new CardViewTextItemModel({
            label: 'version',
            value: module.version,
            key: 'version',
        });
        properties.push(version);
        const active = new CardViewDatetimeItemModel({
            label: 'Build Time',
            value: module.buildTime,
            key: 'build',
            format: 'DD MMM, YYYY HH:MM'
        });
        properties.push(active);
        properties.push(new CardViewBoolItemModel({
            key: 'uninstall',
            label: 'Uninstall',
            value: module.uninstall
        }));
        return properties;
    }
    update(module) {
        this.router.navigate(['.', module.id, 'update'], { relativeTo: this.route });
    }
    uninstall(module) {
        this.moduleManagementService.uninstall(module).subscribe(res => {
            this.moduleManagementService.availableModules().subscribe(res => this.modules = res);
        });
    }
    previousState() {
        window.history.back();
    }
};
ModuleListComponent.ctorParameters = () => [
    { type: ModuleManagementService },
    { type: Router },
    { type: ActivatedRoute }
];
ModuleListComponent = __decorate([
    Component({
        selector: 'module-update-list',
        template: "<mat-card>\n    <mat-card-header>\n        Modules Update\n    </mat-card-header>\n    <mat-card-content>\n        <div class=\"row\" *ngIf=\"modules\">\n            <div class=\"col-sm-12 col-md-6 col-lg-4\"\n                 *ngFor=\"let module of modules\">\n                <mat-card class=\"\">\n                    <mat-card-content>\n                        <adf-card-view [properties]=\"getProperties(module)\"></adf-card-view>\n                    </mat-card-content>\n                    <mat-card-actions style=\"text-align: right !important;\">\n                        <button mat-raised-button color=\"accent\" type=\"button\" (click)=\"uninstall(module)\">Set for Uninstall</button>\n                        <button mat-raised-button type=\"button\" (click)=\"update(module)\">Update</button>\n                    </mat-card-actions>\n                </mat-card>\n            </div>\n        </div>\n        <mat-divider></mat-divider>\n        <mat-card-actions style=\"text-align: right !important;\">\n            <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n        </mat-card-actions>\n    </mat-card-content>\n</mat-card>\n<div class=\"fab-container\">\n    <button mat-fab\n            [matTooltip]=\"'Add Update'\"\n            [routerLink]=\"['new']\">\n        <mat-icon>add</mat-icon>\n    </button>\n</div>\n"
    })
], ModuleListComponent);

let ModuleUpdateComponent = class ModuleUpdateComponent {
    constructor(notification, router, service, loaderService, route) {
        this.notification = notification;
        this.router = router;
        this.service = service;
        this.loaderService = loaderService;
        this.route = route;
        this.properties = [];
        this.update = false;
        this.uploaded = false;
    }
    ngOnInit() {
        this.route.data.subscribe(({ module }) => {
            this.module = !!module && module.body ? module.body : module;
            this.update = !!this.module;
        });
    }
    uploadEvent(file) {
        this.uploaded = false;
        const formData = new FormData();
        formData.append('file', file);
        this.loaderService.open('Uploading module: please wait...');
        this.service.uploadModule(formData)
            .subscribe((res) => {
            this.loaderService.close();
            this.uploaded = true;
            if (res.ok) {
                this.module = res.body;
                this.properties = [];
                const name = new CardViewTextItemModel({
                    label: 'Name',
                    value: this.module.name,
                    key: 'name',
                });
                this.properties.push(name);
                const version = new CardViewTextItemModel({
                    label: 'Version',
                    value: this.module.version,
                    key: 'version',
                });
                this.properties.push(version);
                const buildTime = new CardViewDatetimeItemModel({
                    label: 'Build Time',
                    value: this.module.buildTime,
                    key: 'bp',
                    format: 'DD MMM, YYYY HH:MM'
                });
                this.properties.push(buildTime);
            }
            else {
                this.notification.showError('Module upload failed');
            }
        }, (error => this.notification.showError('Module upload failed: ' + error.text)));
    }
    install() {
        this.loaderService.open('Saving module update: please wait...');
        this.service.install(this.module).subscribe((res) => {
            this.loaderService.close();
            this.router.navigate(['..'], { relativeTo: this.route });
        }, (err) => {
            this.loaderService.close();
            this.notification.showError('Could not save module update: ' + err.text);
        });
    }
    selectEvent(files) {
    }
    cancelEvent() {
        this.files = undefined;
    }
};
ModuleUpdateComponent.ctorParameters = () => [
    { type: NotificationService },
    { type: Router },
    { type: ModuleManagementService },
    { type: AppLoaderService },
    { type: ActivatedRoute }
];
ModuleUpdateComponent = __decorate([
    Component({
        selector: 'module-update-update',
        template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <mat-card-header *ngIf=\"update\">\n                Updating {{module.name}}\n            </mat-card-header>\n            <mat-card-content>\n                <td-file-upload #singleFileUpload [(ngModel)]=\"files\"\n                                (select)=\"selectEvent($event)\"\n                                (upload)=\"uploadEvent($event)\" (cancel)=\"cancelEvent()\"\n                                accept=\".jar\" required>\n                    <mat-icon>file_upload</mat-icon>\n                    <span>{{ singleFileUpload.value?.name }}</span>\n                    <ng-template td-file-input-label>\n                        <mat-icon>attach_file</mat-icon>\n                        <span>Choose a file...</span>\n                        <span [hidden]=\"!singleFileUpload?.required\">*</span>\n                    </ng-template>\n                </td-file-upload>\n            </mat-card-content>\n        </mat-card>\n        <mat-card *ngIf=\"module\">\n            <mat-card-title>\n                Module Details\n            </mat-card-title>\n            <mat-card-content>\n                <adf-card-view [properties]=\"properties\"></adf-card-view>\n                <mat-card-actions>\n                    <button mat-raised-button color=\"primary\" [disabled]=\"!uploaded\" (click)=\"install()\">Save</button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
    })
], ModuleUpdateComponent);

let ModuleResolve = class ModuleResolve {
    constructor(service) {
        this.service = service;
    }
    resolve(route, state) {
        const id = route.params['id'] ? route.params['id'] : null;
        if (id) {
            return this.service.findById(id).pipe(filter((response) => response.ok), map((patient) => patient.body));
        }
        return of({});
    }
};
ModuleResolve.ctorParameters = () => [
    { type: ModuleManagementService }
];
ModuleResolve = __decorate([
    Injectable()
], ModuleResolve);
const ɵ0$2 = {
    authorities: ['ROLE_MODULE_MANAGEMENT'],
    title: 'Modules Update List',
    breadcrumb: 'MODULES UPDATE LIST'
}, ɵ1$2 = {
    title: 'Modules Update List',
    breadcrumb: 'MODULES UPDATE LIST'
}, ɵ2 = {
    title: 'Upload Module Update',
    breadcrumb: 'UPLOAD MODULE UPDATE'
}, ɵ3 = {
    title: 'Upload Module Update',
    breadcrumb: 'UPLOAD MODULE UPDATE'
};
const ROUTES$2 = [
    {
        path: '',
        data: ɵ0$2,
        canActivate: [UserRouteAccessService],
        children: [
            {
                path: '',
                component: ModuleListComponent,
                data: ɵ1$2
            },
            {
                path: 'new',
                component: ModuleUpdateComponent,
                data: ɵ2
            },
            {
                path: ':id/update',
                component: ModuleUpdateComponent,
                resolve: {
                    module: ModuleResolve
                },
                data: ɵ3
            }
        ]
    }
];

let ModulesUpdateModule = class ModulesUpdateModule {
};
ModulesUpdateModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            RouterModule.forChild(ROUTES$2),
            CoreModule,
            MaterialModule,
            CovalentCommonModule,
            CovalentFileModule,
            LamisSharedModule
        ],
        declarations: [
            ModuleListComponent,
            ModuleUpdateComponent
        ],
        providers: [
            ModuleResolve
        ]
    })
], ModulesUpdateModule);

let UpdatesManagementModule = class UpdatesManagementModule {
};
UpdatesManagementModule = __decorate([
    NgModule({
        imports: [
            CommonModule,
            CoreModule,
            MaterialModule
        ],
    })
], UpdatesManagementModule);

let UploadReportComponent = class UploadReportComponent {
    constructor(service, appLoader, notification) {
        this.service = service;
        this.appLoader = appLoader;
        this.notification = notification;
        this.running = false;
    }
    ngOnInit() {
        this.service.states().subscribe(res => this.states = res);
    }
    previousState() {
        window.history.back();
    }
    generate() {
        this.running = true;
        this.appLoader.open('Generating report; please wait...');
        this.service.uploadReport(this.state.id, this.format).subscribe((res) => {
            this.appLoader.close();
            this.running = false;
            const format = this.format === 0 ? 'pdf' : 'xlsx';
            const file = new File([res], `${this.state.name} Database Upload_Biometric Coverage Report.${format}`, { type: 'application/octet-stream' });
            saveAs(file);
        }, (err) => {
            this.appLoader.close();
            this.running = false;
            this.notification.showError(`An error occurred generating report: ${err.message}`);
        });
    }
};
UploadReportComponent.ctorParameters = () => [
    { type: SyncService },
    { type: AppLoaderService },
    { type: NotificationService }
];
UploadReportComponent = __decorate([
    Component({
        selector: 'upload-report',
        template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <mat-card-header>\n                <mat-card-title>\n                    Database Upload/ Biometric Coverage Report\n                </mat-card-title>\n            </mat-card-header>\n            <mat-card-content>\n                <div class=\"row\">\n                    <div class=\"col-md-6\">\n                        <mat-form-field class=\"full-width\">\n                            <mat-label>State</mat-label>\n                            <mat-select [(ngModel)]=\"state\" name=\"state\">\n                                <mat-option></mat-option>\n                                <mat-option *ngFor=\"let c of states\" [value]=\"c\">{{c.name}}\n                                </mat-option>\n                            </mat-select>\n                        </mat-form-field>\n                    </div>\n                    <div class=\"col-md-6\">\n                        <mat-form-field class=\"full-width\">\n                            <mat-label>Format</mat-label>\n                            <mat-select [(ngModel)]=\"format\" name=\"format\">\n                                <mat-option [value]=\"0\">PDF</mat-option>\n                                <mat-option [value]=\"1\">Excel</mat-option>\n                            </mat-select>\n                        </mat-form-field>\n                    </div>\n                </div>\n                <mat-card-actions style=\"text-align: right !important;\">\n                    <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n                    <button mat-raised-button color='primary'\n                            (click)=\"generate()\"\n                            [disabled]=\"!state\"\n                            type=\"button\">\n                        Generate\n                    </button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
    })
], UploadReportComponent);

const ɵ0$3 = {
    title: 'Database Upload Report',
    breadcrumb: 'DATABASE UPLOAD REPORT'
}, ɵ1$3 = {
    authorities: ['ROLE_ADMIN'],
    title: 'Database Upload Report',
    breadcrumb: 'DATABASE UPLOAD REPORT'
};
const ROUTES$3 = [
    {
        path: '',
        data: ɵ0$3,
        children: [
            {
                path: '',
                component: UploadReportComponent,
                data: ɵ1$3,
            }
        ]
    }
];
let UploadReportModule = class UploadReportModule {
};
UploadReportModule = __decorate([
    NgModule({
        declarations: [
            UploadReportComponent
        ],
        imports: [
            CommonModule,
            RouterModule.forChild(ROUTES$3),
            MaterialModule,
            FormsModule
        ]
    })
], UploadReportModule);

/*
 * Public API Surface of Clinic
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DatabaseSyncModule, ModulesUpdateModule, ROUTES$3 as ROUTES, UpdatesManagementModule, UpdatesModule, UploadReportModule, ɵ0$3 as ɵ0, ɵ1$3 as ɵ1, ModulesUpdateComponent as ɵa, ModulesUpdateService as ɵb, SyncService as ɵc, ROUTES as ɵd, modules as ɵe, MaterialModule as ɵf, ROUTES$1 as ɵg, DatabaseSyncComponent as ɵh, ModuleResolve as ɵi, ROUTES$2 as ɵj, ModuleListComponent as ɵk, ModuleManagementService as ɵl, ModuleUpdateComponent as ɵm, UploadReportComponent as ɵn };
//# sourceMappingURL=lamis-database.js.map
