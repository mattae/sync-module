(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@alfresco/adf-core'), require('@angular/common'), require('@angular/core'), require('@angular/material'), require('@angular/router'), require('@covalent/core'), require('@angular/common/http'), require('@lamis/web-core'), require('rxjs/operators'), require('moment'), require('@stomp/ng2-stompjs'), require('@angular/forms'), require('ng2-validation'), require('@mat-datetimepicker/core'), require('rxjs'), require('file-saver')) :
    typeof define === 'function' && define.amd ? define('lamis-database', ['exports', '@alfresco/adf-core', '@angular/common', '@angular/core', '@angular/material', '@angular/router', '@covalent/core', '@angular/common/http', '@lamis/web-core', 'rxjs/operators', 'moment', '@stomp/ng2-stompjs', '@angular/forms', 'ng2-validation', '@mat-datetimepicker/core', 'rxjs', 'file-saver'], factory) :
    (global = global || self, factory(global['lamis-database'] = {}, global.adfCore, global.ng.common, global.ng.core, global.ng.material, global.ng.router, global.core$1, global.ng.common.http, global.webCore, global.rxjs.operators, global.moment_, global.ng2Stompjs, global.ng.forms, global.ng2Validation, global.core$2, global.rxjs, global.fileSaver));
}(this, (function (exports, adfCore, common, core, material, router, core$1, http, webCore, operators, moment_, ng2Stompjs, forms, ng2Validation, core$2, rxjs, fileSaver) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __createBinding(o, m, k, k2) {
        if (k2 === undefined) k2 = k;
        o[k2] = m[k];
    }

    function __exportStar(m, exports) {
        for (var p in m) if (p !== "default" && !exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    var moment = moment_;
    var ModulesUpdateService = /** @class */ (function () {
        function ModulesUpdateService(http, serverUrl) {
            this.http = http;
            this.serverUrl = serverUrl;
            this.resourceUrl = '';
            this.resourceUrl = serverUrl.SERVER_API_URL + '/api/modules-update';
        }
        ModulesUpdateService.prototype.installUpdates = function () {
            return this.http.get(this.resourceUrl + "/install-updates");
        };
        ModulesUpdateService.prototype.availableUpdates = function () {
            return this.http.get(this.resourceUrl + "/available-modules");
        };
        ModulesUpdateService.prototype.checkForUpdates = function () {
            return this.http.get(this.resourceUrl + "/check-for-updates");
        };
        ModulesUpdateService.prototype.lastHeartbeat = function () {
            return this.http.get(this.resourceUrl + "/last-heartbeat").pipe(operators.map(function (res) {
                res = res != null ? moment(res, moment.ISO_8601) : null;
                return res;
            }));
        };
        ModulesUpdateService.ctorParameters = function () { return [
            { type: http.HttpClient },
            { type: undefined, decorators: [{ type: core.Inject, args: [webCore.SERVER_API_URL_CONFIG,] }] }
        ]; };
        ModulesUpdateService.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function ModulesUpdateService_Factory() { return new ModulesUpdateService(core.ɵɵinject(http.HttpClient), core.ɵɵinject(webCore.SERVER_API_URL_CONFIG)); }, token: ModulesUpdateService, providedIn: "root" });
        ModulesUpdateService = __decorate([
            core.Injectable({
                providedIn: 'root'
            }),
            __param(1, core.Inject(webCore.SERVER_API_URL_CONFIG))
        ], ModulesUpdateService);
        return ModulesUpdateService;
    }());

    var SyncService = /** @class */ (function () {
        function SyncService(http, serverUrl) {
            this.http = http;
            this.serverUrl = serverUrl;
            this.resourceUrl = '';
            this.resourceUrl = serverUrl.SERVER_API_URL + '/api/database-sync';
        }
        SyncService.prototype.sync = function () {
            return this.http.get(this.resourceUrl + "/sync");
        };
        SyncService.prototype.downloadBiometrics = function () {
            return this.http.get(this.resourceUrl + "/download-biometrics");
        };
        SyncService.prototype.uploadBiometrics = function () {
            return this.http.get(this.resourceUrl + "/upload-biometrics");
        };
        SyncService.prototype.biometricDownloadCompleted = function () {
            return this.http.get(this.resourceUrl + "/biometric-download-completed");
        };
        SyncService.prototype.biometricUploadCompleted = function () {
            return this.http.get(this.resourceUrl + "/biometric-upload-completed");
        };
        SyncService.prototype.downloadCparp = function (facilityId) {
            return this.http.get(this.resourceUrl + "/cparp/update/" + facilityId);
        };
        SyncService.prototype.downloadMobileRecords = function () {
            return this.http.get(this.resourceUrl + "/download-records");
        };
        SyncService.prototype.init = function () {
            return this.http.get(this.resourceUrl + "/init");
        };
        SyncService.prototype.states = function () {
            return this.http.get(this.resourceUrl + "/states");
        };
        SyncService.prototype.getActiveFacility = function () {
            return this.http.get('/api/facilities/active');
        };
        SyncService.prototype.destroy = function () {
            return this.http.get(this.resourceUrl + "/destroy");
        };
        SyncService.prototype.uploadReport = function (stateId, format) {
            return this.http.get(this.resourceUrl + "/upload-report?stateId=" + stateId + "&format=" + format, { responseType: 'blob' });
        };
        SyncService.ctorParameters = function () { return [
            { type: http.HttpClient },
            { type: undefined, decorators: [{ type: core.Inject, args: [webCore.SERVER_API_URL_CONFIG,] }] }
        ]; };
        SyncService.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function SyncService_Factory() { return new SyncService(core.ɵɵinject(http.HttpClient), core.ɵɵinject(webCore.SERVER_API_URL_CONFIG)); }, token: SyncService, providedIn: "root" });
        SyncService = __decorate([
            core.Injectable({
                providedIn: 'root'
            }),
            __param(1, core.Inject(webCore.SERVER_API_URL_CONFIG))
        ], SyncService);
        return SyncService;
    }());

    var moment$1 = moment_;
    var ModulesUpdateComponent = /** @class */ (function () {
        function ModulesUpdateComponent(service, stompService, syncService) {
            this.service = service;
            this.stompService = stompService;
            this.syncService = syncService;
            this.modules = [];
            this.isUpdating = false;
            this.installed = false;
            this.completeChecking = false;
            this.checked = false;
            this.properties = [];
            this.serverContacted = false;
        }
        ModulesUpdateComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.statusSubscription = this.stompService.watch('/topic/update/download/completed').subscribe(function (msg) {
                _this.completeChecking = msg.body === 'true';
                _this.checked = true;
                _this.service.availableUpdates().subscribe(function (res) { return _this.modules = res; });
            });
            this.service.availableUpdates().subscribe(function (res) { return _this.modules = res; });
            this.service.lastHeartbeat().subscribe(function (res) {
                _this.serverContacted = !!res;
                _this.properties = [];
                _this.properties.push(new adfCore.CardViewDatetimeItemModel({
                    key: 'hb',
                    label: 'Last Contact with Server',
                    value: res,
                    format: 'DD MMM, YYYY HH:MM'
                }));
            });
        };
        ModulesUpdateComponent.prototype.ngOnDestroy = function () {
            this.statusSubscription.unsubscribe();
        };
        ModulesUpdateComponent.prototype.checkForUpdates = function () {
            var _this = this;
            this.service.checkForUpdates().subscribe(function (res) {
                _this.checked = true;
                _this.completeChecking = false;
            });
        };
        ModulesUpdateComponent.prototype.getProperties = function (module) {
            var properties = [];
            var description = new adfCore.CardViewTextItemModel({
                label: 'Name',
                value: module.name,
                key: 'desc',
            });
            properties.push(description);
            var version = new adfCore.CardViewTextItemModel({
                label: 'version',
                value: module.version,
                key: 'version',
            });
            properties.push(version);
            var active = new adfCore.CardViewDatetimeItemModel({
                label: 'Build Time',
                value: moment$1(module.buildTime),
                key: 'active',
                format: 'DD MMM, YYYY HH:MM'
            });
            properties.push(active);
            return properties;
        };
        ModulesUpdateComponent.prototype.updateModules = function () {
            var _this = this;
            this.isUpdating = true;
            this.installed = false;
            this.service.installUpdates().subscribe(function (res) {
                _this.modules = res;
                _this.isUpdating = false;
                _this.installed = true;
                _this.service.availableUpdates().subscribe(function (res) { return _this.modules = res; });
            });
        };
        ModulesUpdateComponent.prototype.previousState = function () {
            window.history.back();
        };
        ModulesUpdateComponent.ctorParameters = function () { return [
            { type: ModulesUpdateService },
            { type: ng2Stompjs.RxStompService },
            { type: SyncService }
        ]; };
        ModulesUpdateComponent = __decorate([
            core.Component({
                selector: 'modules-update',
                template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <mat-card-header *ngIf=\"installed\">\n                <mat-card-title>\n                    <p style=\"color: green\">\n                        Updates installed; please restart service or system\n                    </p>\n                </mat-card-title>\n            </mat-card-header>\n            <ng-container *ngIf=\"!completeChecking && checked\">\n                <div class=\"full-width\">\n                    <mat-progress-bar class=\"full-width\" mode=\"indeterminate\"></mat-progress-bar>\n                </div>\n            </ng-container>\n            <mat-card-content>\n                <adf-card-view [properties]=\"properties\" editable=\"false\"></adf-card-view>\n                <mat-divider [inset]=\"true\"></mat-divider>\n                <div class=\"row\" *ngIf=\"modules\">\n                    <div class=\"col-sm-12 col-md-6 col-lg-4\"\n                         *ngFor=\"let module of modules\">\n                        <mat-card class=\"\">\n                            <mat-card-content>\n                                <adf-card-view [properties]=\"getProperties(module)\"></adf-card-view>\n                            </mat-card-content>\n                        </mat-card>\n                    </div>\n                </div>\n                <adf-empty-content\n                        *ngIf=\"!modules.length && checked && completeChecking\"\n                        icon=\"group\"\n                        [title]=\"'No updates available'\">\n                </adf-empty-content>\n                <mat-divider></mat-divider>\n                <mat-card-actions style=\"text-align: right !important;\">\n                    <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n                    <button mat-raised-button color='accent'\n                            (click)=\"checkForUpdates()\"\n                            [disabled]=\"!completeChecking && checked || isUpdating || !serverContacted\"\n                            type=\"button\">\n                        Check for Updates\n                    </button>\n                    <button mat-raised-button color='primary' *ngIf=\"!!modules.length\"\n                            (click)=\"updateModules()\"\n                            [disabled]=\"!completeChecking && checked || isUpdating\"\n                            type=\"button\">\n                        Install Updates\n                    </button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
            })
        ], ModulesUpdateComponent);
        return ModulesUpdateComponent;
    }());

    var ɵ0 = {
        title: 'Module Updates',
        breadcrumb: 'MODULE UPDATES'
    }, ɵ1 = {
        authorities: ['ROLE_ADMIN'],
        title: 'Module Updates',
        breadcrumb: 'MODULE UPDATES'
    };
    var ROUTES = [
        {
            path: '',
            data: ɵ0,
            children: [
                {
                    path: '',
                    component: ModulesUpdateComponent,
                    data: ɵ1,
                }
            ]
        }
    ];

    var UpdatesModule = /** @class */ (function () {
        function UpdatesModule() {
        }
        UpdatesModule = __decorate([
            core.NgModule({
                declarations: [
                    ModulesUpdateComponent
                ],
                imports: [
                    common.CommonModule,
                    material.MatInputModule,
                    material.MatIconModule,
                    material.MatCardModule,
                    material.MatSelectModule,
                    material.MatButtonModule,
                    router.RouterModule.forChild(ROUTES),
                    material.MatProgressBarModule,
                    forms.FormsModule,
                    core$1.CovalentMessageModule,
                    core$1.CovalentDialogsModule,
                    material.MatTableModule,
                    material.MatListModule,
                    adfCore.CoreModule,
                    forms.ReactiveFormsModule,
                    webCore.MatDateFormatModule,
                    ng2Validation.CustomFormsModule
                ],
                exports: [],
                entryComponents: [],
                providers: []
            })
        ], UpdatesModule);
        return UpdatesModule;
    }());

    /*!
     * @license
     * Copyright 2016 Alfresco Software, Ltd.
     *
     * Licensed under the Apache License, Version 2.0 (the "License");
     * you may not use this file except in compliance with the License.
     * You may obtain a copy of the License at
     *
     *     http://www.apache.org/licenses/LICENSE-2.0
     *
     * Unless required by applicable law or agreed to in writing, software
     * distributed under the License is distributed on an "AS IS" BASIS,
     * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
     * See the License for the specific language governing permissions and
     * limitations under the License.
     */
    function modules() {
        return [
            material.MatAutocompleteModule, material.MatButtonModule, material.MatCardModule, material.MatCheckboxModule,
            material.MatChipsModule, material.MatDatepickerModule, material.MatDialogModule, material.MatGridListModule, material.MatIconModule,
            material.MatInputModule, material.MatListModule, material.MatNativeDateModule, material.MatOptionModule, material.MatProgressSpinnerModule, material.MatRadioModule,
            material.MatRippleModule, material.MatSelectModule, material.MatSlideToggleModule, material.MatTableModule, material.MatTabsModule,
            material.MatMenuModule, material.MatProgressBarModule, material.MatSidenavModule, material.MatSnackBarModule, material.MatToolbarModule,
            material.MatTooltipModule, core$2.MatDatetimepickerModule, core$2.MatNativeDatetimeModule
        ];
    }
    var MaterialModule = /** @class */ (function () {
        function MaterialModule() {
        }
        MaterialModule = __decorate([
            core.NgModule({
                imports: modules(),
                exports: modules()
            })
        ], MaterialModule);
        return MaterialModule;
    }());

    var moment$2 = moment_;
    var DatabaseSyncComponent = /** @class */ (function () {
        function DatabaseSyncComponent(stompService, syncService, notification, loaderService) {
            this.stompService = stompService;
            this.syncService = syncService;
            this.notification = notification;
            this.loaderService = loaderService;
            this.syncing = false;
            this.downloading = false;
            this.serverContacted = false;
            this.tables = '';
            this.properties = [];
        }
        DatabaseSyncComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.syncService.getActiveFacility().subscribe(function (res) { return _this.facility = res; });
            this.properties = [];
            this.statusSubscription = this.stompService.watch('/topic/sync/server-status').subscribe(function (msg) {
                _this.properties = _this.properties.filter(function (i) { return i.key !== 'server'; });
                _this.insertAt(_this.properties, 0, (new adfCore.CardViewDatetimeItemModel({
                    key: 'server',
                    value: msg.body && moment$2(msg.body, moment$2.ISO_8601) || null,
                    label: 'Last contact with Server',
                    format: 'DD MMM, YYYY HH:MM'
                })));
            });
            this.statusSubscription = this.stompService.watch('/topic/sync/sync-status').subscribe(function (msg) {
                _this.properties = _this.properties.filter(function (i) { return i.key !== 'sync'; });
                _this.insertAt(_this.properties, 1, (new adfCore.CardViewDatetimeItemModel({
                    key: 'sync',
                    value: msg.body && moment$2(msg.body, moment$2.ISO_8601) || null,
                    label: 'Last Sync to Server',
                    format: 'DD MMM, YYYY HH:MM'
                })));
            });
            this.syncSubscription = this.stompService.watch('/topic/sync/upload-status/completed').subscribe(function (msg) {
                _this.syncing = msg.body === 'false';
                _this.properties = _this.properties.filter(function (i) { return i.key !== 'status'; });
                _this.properties.push(new adfCore.CardViewBoolItemModel({
                    key: 'status',
                    value: msg.body === 'true',
                    label: 'Upload Completed',
                }));
            });
            this.tableSubscription = this.stompService.watch('/topic/sync/table-status').subscribe(function (msg) {
                _this.tables = msg.body;
            });
            this.serverSubscription = this.stompService.watch('/topic/sync/server').subscribe(function (msg) {
                _this.serverContacted = !!msg.body;
            });
            this.syncService.init().subscribe();
        };
        DatabaseSyncComponent.prototype.ngOnDestroy = function () {
            this.statusSubscription.unsubscribe();
            this.tableSubscription.unsubscribe();
            this.syncSubscription.unsubscribe();
            this.syncService.destroy().subscribe();
            this.serverSubscription.unsubscribe();
        };
        DatabaseSyncComponent.prototype.sync = function () {
            this.syncing = true;
            this.syncService.sync().subscribe();
        };
        DatabaseSyncComponent.prototype.downloadCparp = function () {
            var _this = this;
            this.downloading = true;
            this.loaderService.open('Downloading records, please wait...');
            this.syncService.downloadCparp(this.facility.id).pipe(operators.map(function (res) {
                _this.loaderService.close();
                _this.downloading = false;
                _this.notification.showInfo("Available records for facility successfully downloaded");
            }), operators.catchError(function (err) {
                _this.loaderService.close();
                _this.notification.showError("There was an error downloading records; please try again");
                _this.downloading = false;
                return rxjs.of();
            })).subscribe();
        };
        DatabaseSyncComponent.prototype.downloadMobileRecords = function () {
            var _this = this;
            this.downloading = true;
            this.loaderService.open('Downloading records, please wait...');
            this.syncService.downloadMobileRecords().pipe(operators.map(function (res) {
                _this.loaderService.close();
                _this.downloading = false;
                _this.notification.showInfo("Available records for facility successfully downloaded");
            }), operators.catchError(function (err) {
                _this.loaderService.close();
                _this.notification.showError("There was an error downloading records; please try again");
                _this.downloading = false;
                return rxjs.of();
            })).subscribe();
        };
        DatabaseSyncComponent.prototype.downloadBiometrics = function () {
            var _this = this;
            this.loaderService.open('Downloading biometric data from server. Please wait....');
            this.syncService.downloadBiometrics().subscribe();
            var id = setInterval(function () {
                _this.syncService.biometricDownloadCompleted().subscribe(function (res) {
                    if (res) {
                        _this.loaderService.close();
                        clearInterval(id);
                    }
                });
            }, 10000);
        };
        DatabaseSyncComponent.prototype.uploadBiometrics = function () {
            var _this = this;
            this.loaderService.open('Uploading biometric data to the server. Please wait....');
            this.syncService.uploadBiometrics().subscribe();
            var id = setInterval(function () {
                _this.syncService.biometricUploadCompleted().subscribe(function (res) {
                    if (res) {
                        _this.loaderService.close();
                        clearInterval(id);
                    }
                });
            }, 10000);
        };
        DatabaseSyncComponent.prototype.previousState = function () {
            window.history.back();
        };
        DatabaseSyncComponent.prototype.insertAt = function (array, index) {
            var elementsArray = [];
            for (var _i = 2; _i < arguments.length; _i++) {
                elementsArray[_i - 2] = arguments[_i];
            }
            array.splice.apply(array, __spread([index, 0], elementsArray));
        };
        DatabaseSyncComponent.ctorParameters = function () { return [
            { type: ng2Stompjs.RxStompService },
            { type: SyncService },
            { type: adfCore.NotificationService },
            { type: webCore.AppLoaderService }
        ]; };
        DatabaseSyncComponent = __decorate([
            core.Component({
                selector: 'database-sync',
                template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <ng-container *ngIf=\"syncing\">\n                <div class=\"full-width\">\n                    <mat-progress-bar class=\"full-width\" mode=\"indeterminate\"></mat-progress-bar>\n                </div>\n            </ng-container>\n            <mat-card-header>\n                <mat-card-title>Synchronize Database to Server</mat-card-title>\n                <button mat-icon-button [matMenuTriggerFor]=\"menu\" aria-label=\"Biometrics options\">\n                    <mat-icon>more_vert</mat-icon>\n                </button>\n                <mat-menu #menu=\"matMenu\">\n                    <button mat-menu-item (click)=\"uploadBiometrics()\" [disabled]=\"!serverContacted\">\n                        <mat-icon>file_upload</mat-icon>\n                        <span>Sync Biometrics</span>\n                    </button>\n                    <button mat-menu-item (click)=\"downloadBiometrics()\" [disabled]=\"!serverContacted\">\n                        <mat-icon>file_download</mat-icon>\n                        <span>Download Biometrics</span>\n                    </button>\n                </mat-menu>\n            </mat-card-header>\n            <mat-card-content>\n                <adf-card-view [properties]=\"properties\" [editable]=\"false\"></adf-card-view>\n                <mat-divider [inset]=\"true\"></mat-divider>\n                <mat-form-field class=\"full-width\">\n                    <mat-label>Synced Tables</mat-label>\n                    <textarea matInput disabled [value]='tables' rows=\"10\"></textarea>\n                </mat-form-field>\n                <mat-divider></mat-divider>\n                <mat-card-actions style=\"text-align: right !important;\">\n                    <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n                    <button mat-raised-button color='accent'\n                            (click)=\"downloadMobileRecords()\"\n                            [disabled]=\"downloading || !serverContacted\"\n                            type=\"button\">\n                        Download Mobile Records\n                    </button>\n                    <button mat-raised-button color='accent'\n                            (click)=\"downloadCparp()\"\n                            [disabled]=\"downloading || !serverContacted\"\n                            type=\"button\">\n                        Download CPARP Refill\n                    </button>\n                    <button mat-raised-button color='primary'\n                            (click)=\"sync()\"\n                            [disabled]=\"syncing || !serverContacted\"\n                            type=\"submit\">\n                        Upload to Server\n                    </button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
            })
        ], DatabaseSyncComponent);
        return DatabaseSyncComponent;
    }());

    var ɵ0$1 = {
        title: 'Database Sync',
        breadcrumb: 'DATABASE SYNC'
    }, ɵ1$1 = {
        authorities: ['ROLE_ADMIN'],
        title: 'Database Sync',
        breadcrumb: 'DATABASE SYNC'
    };
    var ROUTES$1 = [
        {
            path: '',
            data: ɵ0$1,
            children: [
                {
                    path: '',
                    component: DatabaseSyncComponent,
                    data: ɵ1$1,
                }
            ]
        }
    ];

    var DatabaseSyncModule = /** @class */ (function () {
        function DatabaseSyncModule() {
        }
        DatabaseSyncModule = __decorate([
            core.NgModule({
                imports: [
                    common.CommonModule,
                    MaterialModule,
                    router.RouterModule.forChild(ROUTES$1),
                    adfCore.CoreModule
                ],
                declarations: [
                    DatabaseSyncComponent
                ]
            })
        ], DatabaseSyncModule);
        return DatabaseSyncModule;
    }());

    var moment$3 = moment_;
    var ModuleManagementService = /** @class */ (function () {
        function ModuleManagementService(http, serverUrl) {
            this.http = http;
            this.serverUrl = serverUrl;
            this.resourceUrl = '';
            this.resourceUrl = serverUrl.SERVER_API_URL + '/api/modules-update';
        }
        ModuleManagementService.prototype.findById = function (id) {
            return this.http.get(this.resourceUrl + "/module/" + id, { observe: 'response' }).pipe(operators.map(function (res) {
                res.body.buildTime = res.body.buildTime != null ? moment$3(res.body.buildTime) : null;
                return res;
            }));
        };
        ModuleManagementService.prototype.availableModules = function () {
            return this.http.get(this.resourceUrl + "/available-modules").pipe(operators.map(function (res) {
                res.forEach(function (m) {
                    m.buildTime = m.buildTime != null ? moment$3(m.buildTime) : null;
                });
                return res;
            }));
        };
        ModuleManagementService.prototype.uploadModule = function (form) {
            return this.http.post(this.resourceUrl + "/upload", form, { observe: 'response' });
        };
        ModuleManagementService.prototype.install = function (module) {
            return this.http.post(this.resourceUrl + "/save-update", module, { observe: 'response' });
        };
        ModuleManagementService.prototype.uninstall = function (module) {
            return this.http.post(this.resourceUrl + "/uninstall", module, { observe: 'response' });
        };
        ModuleManagementService.ctorParameters = function () { return [
            { type: http.HttpClient },
            { type: undefined, decorators: [{ type: core.Inject, args: [webCore.SERVER_API_URL_CONFIG,] }] }
        ]; };
        ModuleManagementService.ngInjectableDef = core.ɵɵdefineInjectable({ factory: function ModuleManagementService_Factory() { return new ModuleManagementService(core.ɵɵinject(http.HttpClient), core.ɵɵinject(webCore.SERVER_API_URL_CONFIG)); }, token: ModuleManagementService, providedIn: "root" });
        ModuleManagementService = __decorate([
            core.Injectable({
                providedIn: 'root'
            }),
            __param(1, core.Inject(webCore.SERVER_API_URL_CONFIG))
        ], ModuleManagementService);
        return ModuleManagementService;
    }());

    var ModuleListComponent = /** @class */ (function () {
        function ModuleListComponent(moduleManagementService, router, route) {
            this.moduleManagementService = moduleManagementService;
            this.router = router;
            this.route = route;
        }
        ModuleListComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.moduleManagementService.availableModules().subscribe(function (res) { return _this.modules = res; });
        };
        ModuleListComponent.prototype.ngOnDestroy = function () {
        };
        ModuleListComponent.prototype.getProperties = function (module) {
            var properties = [];
            var description = new adfCore.CardViewTextItemModel({
                label: 'Name',
                value: module.name,
                key: 'desc',
            });
            properties.push(description);
            var version = new adfCore.CardViewTextItemModel({
                label: 'version',
                value: module.version,
                key: 'version',
            });
            properties.push(version);
            var active = new adfCore.CardViewDatetimeItemModel({
                label: 'Build Time',
                value: module.buildTime,
                key: 'build',
                format: 'DD MMM, YYYY HH:MM'
            });
            properties.push(active);
            properties.push(new adfCore.CardViewBoolItemModel({
                key: 'uninstall',
                label: 'Uninstall',
                value: module.uninstall
            }));
            return properties;
        };
        ModuleListComponent.prototype.update = function (module) {
            this.router.navigate(['.', module.id, 'update'], { relativeTo: this.route });
        };
        ModuleListComponent.prototype.uninstall = function (module) {
            var _this = this;
            this.moduleManagementService.uninstall(module).subscribe(function (res) {
                _this.moduleManagementService.availableModules().subscribe(function (res) { return _this.modules = res; });
            });
        };
        ModuleListComponent.prototype.previousState = function () {
            window.history.back();
        };
        ModuleListComponent.ctorParameters = function () { return [
            { type: ModuleManagementService },
            { type: router.Router },
            { type: router.ActivatedRoute }
        ]; };
        ModuleListComponent = __decorate([
            core.Component({
                selector: 'module-update-list',
                template: "<mat-card>\n    <mat-card-header>\n        Modules Update\n    </mat-card-header>\n    <mat-card-content>\n        <div class=\"row\" *ngIf=\"modules\">\n            <div class=\"col-sm-12 col-md-6 col-lg-4\"\n                 *ngFor=\"let module of modules\">\n                <mat-card class=\"\">\n                    <mat-card-content>\n                        <adf-card-view [properties]=\"getProperties(module)\"></adf-card-view>\n                    </mat-card-content>\n                    <mat-card-actions style=\"text-align: right !important;\">\n                        <button mat-raised-button color=\"accent\" type=\"button\" (click)=\"uninstall(module)\">Set for Uninstall</button>\n                        <button mat-raised-button type=\"button\" (click)=\"update(module)\">Update</button>\n                    </mat-card-actions>\n                </mat-card>\n            </div>\n        </div>\n        <mat-divider></mat-divider>\n        <mat-card-actions style=\"text-align: right !important;\">\n            <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n        </mat-card-actions>\n    </mat-card-content>\n</mat-card>\n<div class=\"fab-container\">\n    <button mat-fab\n            [matTooltip]=\"'Add Update'\"\n            [routerLink]=\"['new']\">\n        <mat-icon>add</mat-icon>\n    </button>\n</div>\n"
            })
        ], ModuleListComponent);
        return ModuleListComponent;
    }());

    var ModuleUpdateComponent = /** @class */ (function () {
        function ModuleUpdateComponent(notification, router, service, loaderService, route) {
            this.notification = notification;
            this.router = router;
            this.service = service;
            this.loaderService = loaderService;
            this.route = route;
            this.properties = [];
            this.update = false;
            this.uploaded = false;
        }
        ModuleUpdateComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.route.data.subscribe(function (_a) {
                var module = _a.module;
                _this.module = !!module && module.body ? module.body : module;
                _this.update = !!_this.module;
            });
        };
        ModuleUpdateComponent.prototype.uploadEvent = function (file) {
            var _this = this;
            this.uploaded = false;
            var formData = new FormData();
            formData.append('file', file);
            this.loaderService.open('Uploading module: please wait...');
            this.service.uploadModule(formData)
                .subscribe(function (res) {
                _this.loaderService.close();
                _this.uploaded = true;
                if (res.ok) {
                    _this.module = res.body;
                    _this.properties = [];
                    var name_1 = new adfCore.CardViewTextItemModel({
                        label: 'Name',
                        value: _this.module.name,
                        key: 'name',
                    });
                    _this.properties.push(name_1);
                    var version = new adfCore.CardViewTextItemModel({
                        label: 'Version',
                        value: _this.module.version,
                        key: 'version',
                    });
                    _this.properties.push(version);
                    var buildTime = new adfCore.CardViewDatetimeItemModel({
                        label: 'Build Time',
                        value: _this.module.buildTime,
                        key: 'bp',
                        format: 'DD MMM, YYYY HH:MM'
                    });
                    _this.properties.push(buildTime);
                }
                else {
                    _this.notification.showError('Module upload failed');
                }
            }, (function (error) { return _this.notification.showError('Module upload failed: ' + error.text); }));
        };
        ModuleUpdateComponent.prototype.install = function () {
            var _this = this;
            this.loaderService.open('Saving module update: please wait...');
            this.service.install(this.module).subscribe(function (res) {
                _this.loaderService.close();
                _this.router.navigate(['..'], { relativeTo: _this.route });
            }, function (err) {
                _this.loaderService.close();
                _this.notification.showError('Could not save module update: ' + err.text);
            });
        };
        ModuleUpdateComponent.prototype.selectEvent = function (files) {
        };
        ModuleUpdateComponent.prototype.cancelEvent = function () {
            this.files = undefined;
        };
        ModuleUpdateComponent.ctorParameters = function () { return [
            { type: adfCore.NotificationService },
            { type: router.Router },
            { type: ModuleManagementService },
            { type: webCore.AppLoaderService },
            { type: router.ActivatedRoute }
        ]; };
        ModuleUpdateComponent = __decorate([
            core.Component({
                selector: 'module-update-update',
                template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <mat-card-header *ngIf=\"update\">\n                Updating {{module.name}}\n            </mat-card-header>\n            <mat-card-content>\n                <td-file-upload #singleFileUpload [(ngModel)]=\"files\"\n                                (select)=\"selectEvent($event)\"\n                                (upload)=\"uploadEvent($event)\" (cancel)=\"cancelEvent()\"\n                                accept=\".jar\" required>\n                    <mat-icon>file_upload</mat-icon>\n                    <span>{{ singleFileUpload.value?.name }}</span>\n                    <ng-template td-file-input-label>\n                        <mat-icon>attach_file</mat-icon>\n                        <span>Choose a file...</span>\n                        <span [hidden]=\"!singleFileUpload?.required\">*</span>\n                    </ng-template>\n                </td-file-upload>\n            </mat-card-content>\n        </mat-card>\n        <mat-card *ngIf=\"module\">\n            <mat-card-title>\n                Module Details\n            </mat-card-title>\n            <mat-card-content>\n                <adf-card-view [properties]=\"properties\"></adf-card-view>\n                <mat-card-actions>\n                    <button mat-raised-button color=\"primary\" [disabled]=\"!uploaded\" (click)=\"install()\">Save</button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
            })
        ], ModuleUpdateComponent);
        return ModuleUpdateComponent;
    }());

    var ModuleResolve = /** @class */ (function () {
        function ModuleResolve(service) {
            this.service = service;
        }
        ModuleResolve.prototype.resolve = function (route, state) {
            var id = route.params['id'] ? route.params['id'] : null;
            if (id) {
                return this.service.findById(id).pipe(operators.filter(function (response) { return response.ok; }), operators.map(function (patient) { return patient.body; }));
            }
            return rxjs.of({});
        };
        ModuleResolve.ctorParameters = function () { return [
            { type: ModuleManagementService }
        ]; };
        ModuleResolve = __decorate([
            core.Injectable()
        ], ModuleResolve);
        return ModuleResolve;
    }());
    var ɵ0$2 = {
        authorities: ['ROLE_MODULE_MANAGEMENT'],
        title: 'Modules Update List',
        breadcrumb: 'MODULES UPDATE LIST'
    }, ɵ1$2 = {
        title: 'Modules Update List',
        breadcrumb: 'MODULES UPDATE LIST'
    }, ɵ2 = {
        title: 'Upload Module Update',
        breadcrumb: 'UPLOAD MODULE UPDATE'
    }, ɵ3 = {
        title: 'Upload Module Update',
        breadcrumb: 'UPLOAD MODULE UPDATE'
    };
    var ROUTES$2 = [
        {
            path: '',
            data: ɵ0$2,
            canActivate: [webCore.UserRouteAccessService],
            children: [
                {
                    path: '',
                    component: ModuleListComponent,
                    data: ɵ1$2
                },
                {
                    path: 'new',
                    component: ModuleUpdateComponent,
                    data: ɵ2
                },
                {
                    path: ':id/update',
                    component: ModuleUpdateComponent,
                    resolve: {
                        module: ModuleResolve
                    },
                    data: ɵ3
                }
            ]
        }
    ];

    var ModulesUpdateModule = /** @class */ (function () {
        function ModulesUpdateModule() {
        }
        ModulesUpdateModule = __decorate([
            core.NgModule({
                imports: [
                    common.CommonModule,
                    router.RouterModule.forChild(ROUTES$2),
                    adfCore.CoreModule,
                    MaterialModule,
                    core$1.CovalentCommonModule,
                    core$1.CovalentFileModule,
                    webCore.LamisSharedModule
                ],
                declarations: [
                    ModuleListComponent,
                    ModuleUpdateComponent
                ],
                providers: [
                    ModuleResolve
                ]
            })
        ], ModulesUpdateModule);
        return ModulesUpdateModule;
    }());

    var UpdatesManagementModule = /** @class */ (function () {
        function UpdatesManagementModule() {
        }
        UpdatesManagementModule = __decorate([
            core.NgModule({
                imports: [
                    common.CommonModule,
                    adfCore.CoreModule,
                    MaterialModule
                ],
            })
        ], UpdatesManagementModule);
        return UpdatesManagementModule;
    }());

    var UploadReportComponent = /** @class */ (function () {
        function UploadReportComponent(service, appLoader, notification) {
            this.service = service;
            this.appLoader = appLoader;
            this.notification = notification;
            this.running = false;
        }
        UploadReportComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.service.states().subscribe(function (res) { return _this.states = res; });
        };
        UploadReportComponent.prototype.previousState = function () {
            window.history.back();
        };
        UploadReportComponent.prototype.generate = function () {
            var _this = this;
            this.running = true;
            this.appLoader.open('Generating report; please wait...');
            this.service.uploadReport(this.state.id, this.format).subscribe(function (res) {
                _this.appLoader.close();
                _this.running = false;
                var format = _this.format === 0 ? 'pdf' : 'xlsx';
                var file = new File([res], _this.state.name + " Database Upload_Biometric Coverage Report." + format, { type: 'application/octet-stream' });
                fileSaver.saveAs(file);
            }, function (err) {
                _this.appLoader.close();
                _this.running = false;
                _this.notification.showError("An error occurred generating report: " + err.message);
            });
        };
        UploadReportComponent.ctorParameters = function () { return [
            { type: SyncService },
            { type: webCore.AppLoaderService },
            { type: adfCore.NotificationService }
        ]; };
        UploadReportComponent = __decorate([
            core.Component({
                selector: 'upload-report',
                template: "<div class=\"lamis-edit-form\">\n    <div class=\"lamis-edit-form-container\">\n        <mat-card>\n            <mat-card-header>\n                <mat-card-title>\n                    Database Upload/ Biometric Coverage Report\n                </mat-card-title>\n            </mat-card-header>\n            <mat-card-content>\n                <div class=\"row\">\n                    <div class=\"col-md-6\">\n                        <mat-form-field class=\"full-width\">\n                            <mat-label>State</mat-label>\n                            <mat-select [(ngModel)]=\"state\" name=\"state\">\n                                <mat-option></mat-option>\n                                <mat-option *ngFor=\"let c of states\" [value]=\"c\">{{c.name}}\n                                </mat-option>\n                            </mat-select>\n                        </mat-form-field>\n                    </div>\n                    <div class=\"col-md-6\">\n                        <mat-form-field class=\"full-width\">\n                            <mat-label>Format</mat-label>\n                            <mat-select [(ngModel)]=\"format\" name=\"format\">\n                                <mat-option [value]=\"0\">PDF</mat-option>\n                                <mat-option [value]=\"1\">Excel</mat-option>\n                            </mat-select>\n                        </mat-form-field>\n                    </div>\n                </div>\n                <mat-card-actions style=\"text-align: right !important;\">\n                    <button mat-raised-button type=\"button\" (click)=\"previousState()\">Back</button>\n                    <button mat-raised-button color='primary'\n                            (click)=\"generate()\"\n                            [disabled]=\"!state\"\n                            type=\"button\">\n                        Generate\n                    </button>\n                </mat-card-actions>\n            </mat-card-content>\n        </mat-card>\n    </div>\n</div>\n"
            })
        ], UploadReportComponent);
        return UploadReportComponent;
    }());

    var ɵ0$3 = {
        title: 'Database Upload Report',
        breadcrumb: 'DATABASE UPLOAD REPORT'
    }, ɵ1$3 = {
        authorities: ['ROLE_ADMIN'],
        title: 'Database Upload Report',
        breadcrumb: 'DATABASE UPLOAD REPORT'
    };
    var ROUTES$3 = [
        {
            path: '',
            data: ɵ0$3,
            children: [
                {
                    path: '',
                    component: UploadReportComponent,
                    data: ɵ1$3,
                }
            ]
        }
    ];
    var UploadReportModule = /** @class */ (function () {
        function UploadReportModule() {
        }
        UploadReportModule = __decorate([
            core.NgModule({
                declarations: [
                    UploadReportComponent
                ],
                imports: [
                    common.CommonModule,
                    router.RouterModule.forChild(ROUTES$3),
                    MaterialModule,
                    forms.FormsModule
                ]
            })
        ], UploadReportModule);
        return UploadReportModule;
    }());

    exports.DatabaseSyncModule = DatabaseSyncModule;
    exports.ModulesUpdateModule = ModulesUpdateModule;
    exports.ROUTES = ROUTES$3;
    exports.UpdatesManagementModule = UpdatesManagementModule;
    exports.UpdatesModule = UpdatesModule;
    exports.UploadReportModule = UploadReportModule;
    exports.ɵ0 = ɵ0$3;
    exports.ɵ1 = ɵ1$3;
    exports.ɵa = ModulesUpdateComponent;
    exports.ɵb = ModulesUpdateService;
    exports.ɵc = SyncService;
    exports.ɵd = ROUTES;
    exports.ɵe = modules;
    exports.ɵf = MaterialModule;
    exports.ɵg = ROUTES$1;
    exports.ɵh = DatabaseSyncComponent;
    exports.ɵi = ModuleResolve;
    exports.ɵj = ROUTES$2;
    exports.ɵk = ModuleListComponent;
    exports.ɵl = ModuleManagementService;
    exports.ɵm = ModuleUpdateComponent;
    exports.ɵn = UploadReportComponent;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=lamis-database.umd.js.map
