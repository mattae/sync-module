export interface Facility {
    id: number;
    name: string;
    active: boolean;
    datimId: string;
}
