package org.fhi360.lamis.modules.database.domain.enumerations;

public enum DetectConflict {
    USE_PK_DATA, USE_OLD_DATA, USE_CHANGED_DATA, USE_TIMESTAMP, USE_VERSION
}
