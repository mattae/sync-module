package org.fhi360.lamis.modules.database.web.rest.vm;

import lombok.Data;

@Data
public class PatientVM {
    private String uuid;
}
