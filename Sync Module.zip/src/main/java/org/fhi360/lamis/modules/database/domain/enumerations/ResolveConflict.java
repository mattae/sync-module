package org.fhi360.lamis.modules.database.domain.enumerations;

public enum ResolveConflict {
    NEWER_WINS, MANUAL, IGNORE, FALLBACK
}
