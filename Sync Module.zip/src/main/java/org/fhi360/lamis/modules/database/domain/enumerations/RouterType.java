package org.fhi360.lamis.modules.database.domain.enumerations;

public enum RouterType {
    column, bsh, subselect, audit
}
