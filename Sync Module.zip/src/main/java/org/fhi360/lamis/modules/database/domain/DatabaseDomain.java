package org.fhi360.lamis.modules.database.domain;

public interface DatabaseDomain {
}
