package org.fhi360.lamis.modules.database.domain.enumerations;

public enum RegistrationRequestStatus {
    NR, IG, OK
}
