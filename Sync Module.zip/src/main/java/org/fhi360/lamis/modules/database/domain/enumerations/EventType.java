package org.fhi360.lamis.modules.database.domain.enumerations;

public enum EventType {
    I, D, U, R, S
}
