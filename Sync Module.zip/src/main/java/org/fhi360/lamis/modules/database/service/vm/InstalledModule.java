package org.fhi360.lamis.modules.database.service.vm;

import lombok.Data;

@Data
public class InstalledModule {
    private String name;
    private String version;
}
