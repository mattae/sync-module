package org.fhi360.lamis.modules.database.domain.enumerations;

public enum TransformType {
    copy, bsh, remove, _const, variable, substring, left, bleft,
    lookup, multiply, identity, math, copyIfChanged, valueMap
}
