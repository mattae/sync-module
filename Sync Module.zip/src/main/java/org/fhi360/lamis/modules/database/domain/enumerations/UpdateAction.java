package org.fhi360.lamis.modules.database.domain.enumerations;

public enum UpdateAction {
    UPD_ROW, DEL_ROW, INS_ROW, NONE
}
