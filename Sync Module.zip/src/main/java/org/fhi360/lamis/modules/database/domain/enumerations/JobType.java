package org.fhi360.lamis.modules.database.domain.enumerations;

public enum JobType {
    BUILT_IN, BSH, JAVA, SQL
}
